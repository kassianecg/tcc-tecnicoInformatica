package hotelperformance;

public class Pagamento {
    
    int idPagamento = 0;
    double valor = 0;
    String descricao = "";
    String Fpagamento = "";
    String data = "";

}
