package hotel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.table.DefaultTableModel;

public class Conexao {

    //NA TELA DE LOGIN TAMBÉM É NECESSÁRIO COLOCAR A SENHA DO BANCO
    //Insira a senha do banco de dados dentro das aspas abaixo
    String passDB = "1234";
    
    //==========-----COMANDOS-----==========\\
    public void executaComando(String comando) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/hotel?useTimezone=true&serverTimezone=UTC",
                    "root", passDB);
            Statement stmt = con.createStatement();
            stmt.execute(comando);
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
    }
    
    
    /*==========-----SELECT DE QUARTOS ANTIGO-----==========*\
    public Quarto[] selectQuartos(String comando) {
        Quarto[] qrt = new Quarto[1000];
        int cont = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/hotel?useTimezone=true&serverTimezone=UTC",
                    "root", passDB);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(comando);

            while (rs.next()) {
                Quarto q = new Quarto();
                q.numero = rs.getInt("numero");
                q.andar = rs.getInt("andar");
                q.tipo = rs.getString("tipo");
                q.descricao = rs.getString("descricao");
                q.preco = rs.getDouble("preco");
                q.disponivel = rs.getString("disponivel");
                qrt[cont] = q;
                cont++;
            }
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        return qrt;
    }*/

    
    //==========-----SELECT DE HOSPEDES-----==========\\
    public Hospede[] selectHospedes(String comando) {
        Hospede[] hpd = new Hospede[1000];
        int cont = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/hotel?useTimezone=true&serverTimezone=UTC",
                    "root", passDB);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(comando);

            while (rs.next()) {
                Hospede h = new Hospede();
                h.idHospede = rs.getInt("idHospede");
                h.nome = rs.getString("nome");
                h.sexo = rs.getString("sexo");
                h.nascimento = new SimpleDateFormat("dd/MM/yyyy").format(rs.getDate("nascimento"));
                h.cidade = rs.getString("cidade");
                h.cpf = rs.getString("cpf");
                h.rg = rs.getString("rg");
                h.telefone = rs.getString("telefone");
                hpd[cont] = h;
                cont++;
            }
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        return hpd;
    }

    //==========-----SELECT DE FUNCIONARIOS-----==========\\
    public Funcionario[] selectFuncionarios(String comando) {
        Funcionario[] fcnr = new Funcionario[1000];
        int cont = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/hotel?useTimezone=true&serverTimezone=UTC",
                    "root", passDB);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(comando);

            while (rs.next()) {
                Funcionario f = new Funcionario();
                f.idFuncionario = rs.getInt("idFuncionario");
                f.nome = rs.getString("nome");
                f.sexo = rs.getString("sexo");
                f.nascimento = new SimpleDateFormat("dd/MM/yyyy").format(rs.getDate("nascimento"));
                f.endereco = rs.getString("endereco");
                f.dataContratacao = new SimpleDateFormat("dd/MM/yyyy").format(rs.getDate("dataContratacao"));
                f.cargo = rs.getString("cargo");
                f.cargaHoraria = rs.getString("cargaHoraria");
                f.cpf = rs.getString("cpf");
                f.rg = rs.getString("rg");
                f.telefone = rs.getString("telefone");
                f.email = rs.getString("email");
                f.dataCadastro = new SimpleDateFormat("dd/MM/yyyy").format(rs.getDate("dataCadastro"));
                f.usuario = rs.getString("usuairo");
                f.senha = rs.getString("senha");
                fcnr[cont] = f;
                cont++;
            }
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        return fcnr;
    }

    
    //==========-----SELECT DE RESERVAS-----==========\\
    public Reserva[] selectReservas(String comando) {
        Reserva[] rsv = new Reserva[1000];
        int cont = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/hotel?useTimezone=true&serverTimezone=UTC",
                    "root", passDB);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(comando);

            while (rs.next()) {
                Reserva r = new Reserva();
                r.idHospede = rs.getInt("id_hospede");
                r.id = rs.getInt("idReserva");
                r.numQuarto = rs.getInt("num_quarto");
                r.consumo = rs.getDouble("consumo");
                r.estado = rs.getString("estado");
                r.dataEntrada = new SimpleDateFormat("dd/MM/yyyy").format(rs.getDate("dataEntrada"));
                r.dataSaida = new SimpleDateFormat("dd/MM/yyyy").format(rs.getDate("dataSaida"));
                rsv[cont] = r ;
                cont++;
            }
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        return rsv;
    }

        
        
//final
}
