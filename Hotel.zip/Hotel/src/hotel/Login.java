package hotel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
        errouTxt.setVisible(false);
        usuarioTxt.requestFocus();
    }

    public void Logar() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel?useTimezone=true&serverTimezone=UTC",
                    "root", new Conexao().passDB);
            String sql = "SELECT usuario,senha FROM funcionarios WHERE usuario='" + usuarioTxt.getText().replace("'", "") + "' AND senha='" + senhaTxt.getText().replace("'", "") + "';";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                //quando o login é verdadeiro
                Inicial inicial = new Inicial();
                inicial.setVisible(true);
                dispose();
                System.out.println("Login efetuado!");
            } else {
                //quando o login é falso
                errouTxt.setVisible(true);
                System.out.println("Erro de Login!");
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        /*----------ESTRUTURA DE SELECT----------*\
        
        Usuario[] user = new Conexao().selectUsuario("SELECT * FROM usuario");
        for (int c = 0; c < 100; c++) {
            if (user[c] != null) {
                //criar comando aqui para armazenar em objetos retornados em arrays
                
                }
            }
        }*/
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        usuarioTxt = new javax.swing.JTextField();
        senhaTxt = new javax.swing.JPasswordField();
        errouTxt = new javax.swing.JLabel();
        sairTxt = new javax.swing.JLabel();
        entrarTxt = new javax.swing.JLabel();
        Fundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAutoRequestFocus(false);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        usuarioTxt.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        usuarioTxt.setForeground(new java.awt.Color(0, 127, 255));
        usuarioTxt.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        usuarioTxt.setBorder(null);
        usuarioTxt.setOpaque(false);
        usuarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                usuarioTxtKeyPressed(evt);
            }
        });
        getContentPane().add(usuarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 100, 280, 30));

        senhaTxt.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        senhaTxt.setForeground(new java.awt.Color(0, 127, 255));
        senhaTxt.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        senhaTxt.setBorder(null);
        senhaTxt.setOpaque(false);
        senhaTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                senhaTxtActionPerformed(evt);
            }
        });
        senhaTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                senhaTxtKeyPressed(evt);
            }
        });
        getContentPane().add(senhaTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 215, 280, 30));

        errouTxt.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        errouTxt.setForeground(new java.awt.Color(255, 0, 0));
        errouTxt.setText("Usuário ou senha incorretos, tente novamente.");
        getContentPane().add(errouTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 250, -1, -1));

        sairTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sairTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sairTxtMouseClicked(evt);
            }
        });
        getContentPane().add(sairTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 280, 40, 20));

        entrarTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        entrarTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                entrarTxtMouseClicked(evt);
            }
        });
        getContentPane().add(entrarTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 270, 90, 30));

        Fundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/img-login.png"))); // NOI18N
        Fundo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(Fundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 400));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void sairTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sairTxtMouseClicked
        System.out.println("Software Finalizado!");
        System.exit(0);
    }//GEN-LAST:event_sairTxtMouseClicked

    private void senhaTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_senhaTxtActionPerformed
        Logar();
    }//GEN-LAST:event_senhaTxtActionPerformed

    private void entrarTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_entrarTxtMouseClicked
        Logar();
    }//GEN-LAST:event_entrarTxtMouseClicked

    private void usuarioTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_usuarioTxtKeyTyped
        String caracteres = "0987654321abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáàãâéèêíìóòôõúùûÁÀÃÂÉÈÊÍÌÓÒÔÕÚÙÛ";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_usuarioTxtKeyTyped

    private void senhaTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_senhaTxtKeyTyped
        String caracteres = "0987654321abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáàãâéèêíìóòôõúùûÁÀÃÂÉÈÊÍÌÓÒÔÕÚÙÛ";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_senhaTxtKeyTyped

    private void senhaTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_senhaTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            Logar();
        }
    }//GEN-LAST:event_senhaTxtKeyPressed

    private void usuarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_usuarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            senhaTxt.requestFocus();
        }
    }//GEN-LAST:event_usuarioTxtKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Fundo;
    private javax.swing.JLabel entrarTxt;
    private javax.swing.JLabel errouTxt;
    private javax.swing.JLabel sairTxt;
    private javax.swing.JPasswordField senhaTxt;
    private javax.swing.JTextField usuarioTxt;
    // End of variables declaration//GEN-END:variables
}
