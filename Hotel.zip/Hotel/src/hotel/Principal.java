package hotel;

public class Principal {

    public static void main(String[] args) {

        //Login l = new Login();
        //l.setVisible(true);

        Inicial n = new Inicial();
        n.setVisible(true);
        System.out.println("Iniciando Software...");

    }

}
