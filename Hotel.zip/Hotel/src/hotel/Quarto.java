package hotel;

public class Quarto {

    int numero = 0;
    int andar = 0;
    double preco = 0;
    String tipo = "";
    String descricao = "";
    String disponivel = "";// valores possíveis: "S" e "N"

    public void gravar() {
        new Conexao().executaComando("INSERT INTO quartos(numero,andar,tipo,descricao,preco,disponivel) VALUES ("
                + numero + "," + andar + ",'" + tipo + "','" + descricao + "'," + preco + ",'S');");
    }

    /*@Override
    public String toString() {
    String info = "Nº: " + numero + "  Andar: " + andar + "  Preço: " + preco + "  Disponível: " + disponivel;
    return info;
    }*/
    
}
