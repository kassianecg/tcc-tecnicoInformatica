package hotel;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class Inicial extends javax.swing.JFrame {

    public Inicial() {
        initComponents();
        esconderPaiFilho();
        esconderBtnFuncoes();
        panelInicio.setVisible(true);

    }

    public void corBtnGeral() {//defini todas as cores dos botões pricipais como desativado(azul-escuro)
        inicioBtn1.setBackground(new Color(0, 73, 147));
        funcionarioBtn1.setBackground(new Color(0, 73, 147));
        hospedeBtn1.setBackground(new Color(0, 73, 147));
        quartoBtn1.setBackground(new Color(0, 73, 147));
        reservaBtn1.setBackground(new Color(0, 73, 147));
        pagamentoBtn.setBackground(new Color(0, 73, 147));

    }

    public void esconderBtnFuncoes() {//esconde todos os botões de funções

        //botões das funções
        cadastrarFuncFuncaoBtn.setVisible(false);
        cadastrarHospFuncaoBtn.setVisible(false);
        cadastrarQuaFuncaoBtn.setVisible(false);
        
        verFuncFuncaoBtn.setVisible(false);
        verHospFuncaoBtn.setVisible(false);
        
        excluirHospFuncaoBtn.setVisible(false);
        excluirFuncFuncaoBtn.setVisible(false);

    }

    public void corBtnFuncoes() {//defini todas as cores dos botões de função de alguma aba como desativado(cinza)

        //Botões
        cadastrarFuncFuncaoBtn.setBackground(new Color(102, 102, 102));
        cadastrarHospFuncaoBtn.setBackground(new Color(102, 102, 102));
        
        verFuncFuncaoBtn.setBackground(new Color(102, 102, 102));
        verHospFuncaoBtn.setBackground(new Color(102, 102, 102));
        
        excluirHospFuncaoBtn.setBackground(new Color(102, 102, 102));
        excluirFuncFuncaoBtn.setBackground(new Color(102, 102, 102));

        /*\
         *
         *
         *
        \*/
        
        
        //Label's
        cadastrarFunciFuncao.setForeground(new Color(255, 255, 255));
        cadastrarHospFuncao.setForeground(new Color(255, 255, 255));
        
        verHospFuncao.setForeground(new Color(255, 255, 255));
        verFuncFuncao.setForeground(new Color(255, 255, 255));
        
        excluirHospFuncao.setForeground(new Color(255, 255, 255));
        excluirFuncFuncao.setForeground(new Color(255, 255, 255));

    }

    public void esconderPaiFilho() {//Esconde todos os panel's pais e filhos, e todos os label's de erro

        //panel's
        panelInicio.setVisible(false);//pai
        
        panelFuncionario.setVisible(false);//pai
            cadastrarFuncionario.setVisible(false);//filho
            
        panelHospede.setVisible(false);//pai
            cadastrarHospede.setVisible(false);//filho
            
        panelQuarto.setVisible(false);//pai
            cadastrarQuarto.setVisible(false);//filho
            
        panelReserva.setVisible(false);//pai
            cadastrarReserva.setVisible(false);//filho
            
        panelPagamento.setVisible(false);//pai
            cadastrarPagamento.setVisible(false);//filho
            

        //label's dos erros
        erroQuarto.setText("");
        erroHospede.setText("");
        erroFuncionario.setText("");
        erroPag.setText("");
        erroReserva.setText("");
    }

    public void selectHospedesJTable(String sql) {
        try {
            Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel?useTimezone=true&serverTimezone=UTC",
                    "root", new Conexao().passDB);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            DefaultTableModel model = (DefaultTableModel) selectHospedeReserva.getModel();
            model.setNumRows(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("idHospede"),
                    rs.getString("nome"),
                    rs.getString("sexo"),
                    rs.getString("nascimento"),
                    rs.getString("cpf"),
                    rs.getString("rg"),
                    rs.getString("telefone"),
                    rs.getString("cidade")
                });
            }
            con.close();
        } catch (SQLException ex) {
            System.out.println("o erro foi " + ex);
        }
    }

    public void selectQuartosJTable(String sql) {
        try {
            Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel?useTimezone=true&serverTimezone=UTC",
                    "root", new Conexao().passDB);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            DefaultTableModel model = (DefaultTableModel) selectQuartoReserva.getModel();
            model.setNumRows(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("numero"),
                    rs.getInt("andar"),
                    rs.getDouble("preco"),
                    rs.getString("tipo"),
                    rs.getString("descricao")
                });
            }
            con.close();
        } catch (SQLException ex) {
            System.out.println("o erro foi " + ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelEsquerdo = new javax.swing.JPanel();
        iconHotelTxt = new javax.swing.JLabel();
        inicioBtn1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        inicioTxt1 = new javax.swing.JLabel();
        funcionarioBtn1 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        funcionarioTxt1 = new javax.swing.JLabel();
        hospedeBtn1 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        hospedeTxt1 = new javax.swing.JLabel();
        quartoBtn1 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        quartoTxt1 = new javax.swing.JLabel();
        reservaBtn1 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        reservaTxt1 = new javax.swing.JLabel();
        pagamentoBtn = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        transacaoTxt1 = new javax.swing.JLabel();
        PanelTopo = new javax.swing.JPanel();
        sairTxt = new javax.swing.JLabel();
        minimizarTxt = new javax.swing.JLabel();
        titleSoftware = new javax.swing.JLabel();
        FuncoesAbas = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        usuario1Txt = new javax.swing.JLabel();
        avisoTxt = new javax.swing.JLabel();
        calendarioTxt = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        cadastrarQuaFuncaoBtn = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        cadastrarQuaFuncao = new javax.swing.JLabel();
        cadastrarFuncFuncaoBtn = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        cadastrarFunciFuncao = new javax.swing.JLabel();
        cadastrarHospFuncaoBtn = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        cadastrarHospFuncao = new javax.swing.JLabel();
        excluirHospFuncaoBtn = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        excluirHospFuncao = new javax.swing.JLabel();
        excluirFuncFuncaoBtn = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        excluirFuncFuncao = new javax.swing.JLabel();
        verFuncFuncaoBtn = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        verFuncFuncao = new javax.swing.JLabel();
        verHospFuncaoBtn = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        verHospFuncao = new javax.swing.JLabel();
        PanelPrincipal = new javax.swing.JPanel();
        panelInicio = new javax.swing.JPanel();
        iInicio = new javax.swing.JLabel();
        panelFuncionario = new javax.swing.JPanel();
        cadastrarFuncionario = new javax.swing.JPanel();
        cadastrarNovoFuncionario = new javax.swing.JLabel();
        nomeFuncionario = new javax.swing.JLabel();
        nomeFuncionarioTxt = new javax.swing.JTextField();
        sexoFuncionario = new javax.swing.JLabel();
        sexoFuncionarioTxt = new javax.swing.JComboBox<>();
        nascimentoFuncionario = new javax.swing.JLabel();
        anoNascFuncionarioTxt = new javax.swing.JComboBox<>();
        diaNascFuncionarioTxt = new javax.swing.JComboBox<>();
        mesNascFuncionarioTxt = new javax.swing.JComboBox<>();
        rgFuncionario = new javax.swing.JLabel();
        rgFuncionarioTxt = new javax.swing.JTextField();
        cpfFuncionario = new javax.swing.JLabel();
        cpfFuncionarioTxt = new javax.swing.JTextField();
        emailFuncionario = new javax.swing.JLabel();
        emaiFuncionarioTxt = new javax.swing.JTextField();
        telefoneFuncionario = new javax.swing.JLabel();
        telefoneFuncionarioTxt = new javax.swing.JTextField();
        dataContratacaoFuncionario = new javax.swing.JLabel();
        diaConNovoFunc = new javax.swing.JComboBox<>();
        mesConNovoFunc = new javax.swing.JComboBox<>();
        anoConNovoFunc = new javax.swing.JComboBox<>();
        cargaHorariaFuncionario = new javax.swing.JLabel();
        cargaHorariaFuncionarioTxt = new javax.swing.JComboBox<>();
        cargoFuncionario = new javax.swing.JLabel();
        cargoFuncionarioTxt = new javax.swing.JTextField();
        enderecoFuncionario = new javax.swing.JLabel();
        enderecoFuncionarioTxt = new javax.swing.JTextField();
        cadastrarFuncionarioBtn = new javax.swing.JButton();
        infoFuncionario = new javax.swing.JLabel();
        erroFuncionario = new javax.swing.JLabel();
        usuarioFuncionario = new javax.swing.JLabel();
        usuarioFuncionarioTxt = new javax.swing.JTextField();
        senhaFuncionario = new javax.swing.JLabel();
        senhaFuncionarioTxt = new javax.swing.JTextField();
        panelHospede = new javax.swing.JPanel();
        cadastrarHospede = new javax.swing.JPanel();
        cadastrarNovoHospede = new javax.swing.JLabel();
        nomeHospede = new javax.swing.JLabel();
        nomeHospedeTxt = new javax.swing.JTextField();
        sexoHospedeTxt = new javax.swing.JComboBox<>();
        sexoHospede = new javax.swing.JLabel();
        nascimentoHospede = new javax.swing.JLabel();
        diaNascHospedeTxt = new javax.swing.JComboBox<>();
        mesNascHospedeTxt = new javax.swing.JComboBox<>();
        anoNascHospedeTxt = new javax.swing.JComboBox<>();
        rgHospedeTxt = new javax.swing.JTextField();
        rgHospede = new javax.swing.JLabel();
        cpfHospede = new javax.swing.JLabel();
        cpfHospedeTxt = new javax.swing.JTextField();
        telefoneHospede = new javax.swing.JLabel();
        telefoneHospedeTxt = new javax.swing.JTextField();
        cadastrarHospedeBtn = new javax.swing.JButton();
        cidadeHospede = new javax.swing.JLabel();
        cidadeHospedeTxt = new javax.swing.JTextField();
        erroHospede = new javax.swing.JLabel();
        panelQuarto = new javax.swing.JPanel();
        cadastrarQuarto = new javax.swing.JPanel();
        cadastrarNovoQuarto = new javax.swing.JLabel();
        numQuarto = new javax.swing.JLabel();
        numQuartoTxt = new javax.swing.JTextField();
        andarQuarto = new javax.swing.JLabel();
        andarQuartoTxt = new javax.swing.JTextField();
        tipoQuarto = new javax.swing.JLabel();
        tipoQuartoTxt = new javax.swing.JTextField();
        descricaoQuarto = new javax.swing.JLabel();
        descricaoQuartoTxt = new javax.swing.JTextField();
        precoQuarto = new javax.swing.JLabel();
        precoQuartoTxt = new javax.swing.JTextField();
        cadastrarQuartoBtn = new javax.swing.JButton();
        erroQuarto = new javax.swing.JLabel();
        panelReserva = new javax.swing.JPanel();
        cadastrarReserva = new javax.swing.JPanel();
        cadastrarNovaReserva = new javax.swing.JLabel();
        numQuartoReserva = new javax.swing.JLabel();
        numQuartoReservaTxt = new javax.swing.JTextField();
        consumoReserva = new javax.swing.JLabel();
        consumoReservaTxt = new javax.swing.JTextField();
        estadoReserva = new javax.swing.JLabel();
        idHospedeReserva = new javax.swing.JLabel();
        idHospedeReservaTxt = new javax.swing.JTextField();
        dataEntradaReserva = new javax.swing.JLabel();
        estadoReservaTxt = new javax.swing.JComboBox<>();
        mesEntradaReserva = new javax.swing.JComboBox<>();
        anoEntradaReserva = new javax.swing.JComboBox<>();
        verQuartoBtn = new javax.swing.JButton();
        dataSaidaReserva = new javax.swing.JLabel();
        diaSaidaReserva = new javax.swing.JComboBox<>();
        mesSaidaReserva = new javax.swing.JComboBox<>();
        anoSaidaReserva = new javax.swing.JComboBox<>();
        erroReserva = new javax.swing.JLabel();
        diaEntradaReserva1 = new javax.swing.JComboBox<>();
        cadastrarReservaBtn = new javax.swing.JButton();
        selectHospedesReservas = new javax.swing.JScrollPane();
        selectHospedeReserva = new javax.swing.JTable();
        infoSelectReserva = new javax.swing.JLabel();
        descricaoQuartosReservas = new javax.swing.JScrollPane();
        descricaoQuartoReserva = new javax.swing.JTextPane();
        selectQuartosReservas = new javax.swing.JScrollPane();
        selectQuartoReserva = new javax.swing.JTable();
        verHospedeBtn = new javax.swing.JButton();
        panelPagamento = new javax.swing.JPanel();
        cadastrarPagamento = new javax.swing.JPanel();
        cadastrarNovoPag = new javax.swing.JLabel();
        valorPag = new javax.swing.JLabel();
        valorPagTxt = new javax.swing.JTextField();
        idFluxoPag = new javax.swing.JLabel();
        idFluxoPagTxt = new javax.swing.JTextField();
        dataPag = new javax.swing.JLabel();
        diaPag = new javax.swing.JComboBox<>();
        mesPag = new javax.swing.JComboBox<>();
        anoPag = new javax.swing.JComboBox<>();
        formaPag = new javax.swing.JLabel();
        formaPagTxt = new javax.swing.JTextField();
        cadastrarPagBtn = new javax.swing.JButton();
        erroPag = new javax.swing.JLabel();
        pesquisarTxt = new javax.swing.JTextField();
        ipesquisarTxt = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1100, 600));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelEsquerdo.setBackground(new java.awt.Color(0, 30, 60));
        PanelEsquerdo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        iconHotelTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/icon-hotel.png"))); // NOI18N
        PanelEsquerdo.add(iconHotelTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 18, 140, 150));

        inicioBtn1.setBackground(new java.awt.Color(0, 19, 39));
        inicioBtn1.setToolTipText("");
        inicioBtn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        inicioBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inicioBtn1MouseClicked(evt);
            }
        });
        inicioBtn1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(0, 93, 187));
        jPanel7.setPreferredSize(new java.awt.Dimension(3, 100));
        inicioBtn1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 30));

        inicioTxt1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        inicioTxt1.setForeground(new java.awt.Color(255, 255, 255));
        inicioTxt1.setText("Início");
        inicioBtn1.add(inicioTxt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 20));

        PanelEsquerdo.add(inicioBtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 160, 30));

        funcionarioBtn1.setBackground(new java.awt.Color(0, 73, 147));
        funcionarioBtn1.setToolTipText("");
        funcionarioBtn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        funcionarioBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                funcionarioBtn1MouseClicked(evt);
            }
        });
        funcionarioBtn1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(0, 93, 187));
        jPanel9.setPreferredSize(new java.awt.Dimension(3, 100));
        funcionarioBtn1.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        funcionarioTxt1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        funcionarioTxt1.setForeground(new java.awt.Color(255, 255, 255));
        funcionarioTxt1.setText("Funcionários");
        funcionarioBtn1.add(funcionarioTxt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 20));

        PanelEsquerdo.add(funcionarioBtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 160, 30));

        hospedeBtn1.setBackground(new java.awt.Color(0, 73, 147));
        hospedeBtn1.setToolTipText("");
        hospedeBtn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        hospedeBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hospedeBtn1MouseClicked(evt);
            }
        });
        hospedeBtn1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setBackground(new java.awt.Color(0, 93, 187));
        jPanel10.setPreferredSize(new java.awt.Dimension(3, 100));
        hospedeBtn1.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        hospedeTxt1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        hospedeTxt1.setForeground(new java.awt.Color(255, 255, 255));
        hospedeTxt1.setText("Hóspedes");
        hospedeBtn1.add(hospedeTxt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 20));

        PanelEsquerdo.add(hospedeBtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 160, 30));

        quartoBtn1.setBackground(new java.awt.Color(0, 73, 147));
        quartoBtn1.setToolTipText("");
        quartoBtn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        quartoBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                quartoBtn1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                d(evt);
            }
        });
        quartoBtn1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel11.setBackground(new java.awt.Color(0, 93, 187));
        jPanel11.setPreferredSize(new java.awt.Dimension(3, 100));
        quartoBtn1.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        quartoTxt1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        quartoTxt1.setForeground(new java.awt.Color(255, 255, 255));
        quartoTxt1.setText("Quartos");
        quartoBtn1.add(quartoTxt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 20));

        PanelEsquerdo.add(quartoBtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 160, 30));

        reservaBtn1.setBackground(new java.awt.Color(0, 73, 147));
        reservaBtn1.setToolTipText("");
        reservaBtn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        reservaBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reservaBtn1MouseClicked(evt);
            }
        });
        reservaBtn1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel12.setBackground(new java.awt.Color(0, 93, 187));
        jPanel12.setPreferredSize(new java.awt.Dimension(3, 100));
        reservaBtn1.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        reservaTxt1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        reservaTxt1.setForeground(new java.awt.Color(255, 255, 255));
        reservaTxt1.setText("Reservas");
        reservaBtn1.add(reservaTxt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 20));

        PanelEsquerdo.add(reservaBtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 160, 30));

        pagamentoBtn.setBackground(new java.awt.Color(0, 73, 147));
        pagamentoBtn.setToolTipText("");
        pagamentoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pagamentoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pagamentoBtnMouseClicked(evt);
            }
        });
        pagamentoBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel13.setBackground(new java.awt.Color(0, 93, 187));
        jPanel13.setPreferredSize(new java.awt.Dimension(3, 100));
        pagamentoBtn.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        transacaoTxt1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        transacaoTxt1.setForeground(new java.awt.Color(255, 255, 255));
        transacaoTxt1.setText("Pagamentos");
        pagamentoBtn.add(transacaoTxt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 20));

        PanelEsquerdo.add(pagamentoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 160, 30));

        getContentPane().add(PanelEsquerdo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 600));

        PanelTopo.setBackground(new java.awt.Color(0, 46, 93));
        PanelTopo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sairTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/icon-sair.png"))); // NOI18N
        sairTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sairTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sairTxtMouseClicked(evt);
            }
        });
        PanelTopo.add(sairTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(916, 16, -1, 10));

        minimizarTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/icon-minimizar.png"))); // NOI18N
        minimizarTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        minimizarTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizarTxtMouseClicked(evt);
            }
        });
        PanelTopo.add(minimizarTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(896, 16, 14, 10));

        titleSoftware.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        titleSoftware.setForeground(new java.awt.Color(255, 255, 255));
        titleSoftware.setText("Hotel Managment Software");
        PanelTopo.add(titleSoftware, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 350, 30));

        getContentPane().add(PanelTopo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 940, 50));

        FuncoesAbas.setBackground(new java.awt.Color(0, 46, 93));
        FuncoesAbas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(0, 73, 147));
        jPanel5.setMinimumSize(new java.awt.Dimension(50, 10));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        FuncoesAbas.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 70));

        jPanel4.setBackground(new java.awt.Color(0, 93, 187));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        usuario1Txt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/icon-usuario.png"))); // NOI18N
        usuario1Txt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel4.add(usuario1Txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, -1, 30));

        avisoTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/icon-aviso.png"))); // NOI18N
        avisoTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel4.add(avisoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, 30));

        calendarioTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/icon-calendario.png"))); // NOI18N
        calendarioTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel4.add(calendarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(156, 30, -1, 30));
        jPanel4.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 210, 10));

        FuncoesAbas.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 230, 120));

        cadastrarQuaFuncaoBtn.setBackground(new java.awt.Color(102, 102, 102));
        cadastrarQuaFuncaoBtn.setToolTipText("");
        cadastrarQuaFuncaoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cadastrarQuaFuncaoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cadastrarQuaFuncaoBtnMouseClicked(evt);
            }
        });
        cadastrarQuaFuncaoBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel21.setBackground(new java.awt.Color(204, 204, 204));
        jPanel21.setPreferredSize(new java.awt.Dimension(3, 100));
        cadastrarQuaFuncaoBtn.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        cadastrarQuaFuncao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        cadastrarQuaFuncao.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarQuaFuncao.setText("Cadastrar Quarto");
        cadastrarQuaFuncaoBtn.add(cadastrarQuaFuncao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 30));

        FuncoesAbas.add(cadastrarQuaFuncaoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 230, 40));

        cadastrarFuncFuncaoBtn.setBackground(new java.awt.Color(102, 102, 102));
        cadastrarFuncFuncaoBtn.setToolTipText("");
        cadastrarFuncFuncaoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cadastrarFuncFuncaoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cadastrarFuncFuncaoBtnMouseClicked(evt);
            }
        });
        cadastrarFuncFuncaoBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel14.setBackground(new java.awt.Color(204, 204, 204));
        jPanel14.setPreferredSize(new java.awt.Dimension(3, 100));
        cadastrarFuncFuncaoBtn.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        cadastrarFunciFuncao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        cadastrarFunciFuncao.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarFunciFuncao.setText("Cadastrar Funcionário");
        cadastrarFuncFuncaoBtn.add(cadastrarFunciFuncao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 20));

        FuncoesAbas.add(cadastrarFuncFuncaoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 230, 40));

        cadastrarHospFuncaoBtn.setBackground(new java.awt.Color(102, 102, 102));
        cadastrarHospFuncaoBtn.setToolTipText("");
        cadastrarHospFuncaoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cadastrarHospFuncaoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cadastrarHospFuncaoBtnMouseClicked(evt);
            }
        });
        cadastrarHospFuncaoBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel17.setBackground(new java.awt.Color(204, 204, 204));
        jPanel17.setPreferredSize(new java.awt.Dimension(3, 100));
        cadastrarHospFuncaoBtn.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        cadastrarHospFuncao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        cadastrarHospFuncao.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarHospFuncao.setText("Cadastrar Hóspede");
        cadastrarHospFuncaoBtn.add(cadastrarHospFuncao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 30));

        FuncoesAbas.add(cadastrarHospFuncaoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 230, 40));

        excluirHospFuncaoBtn.setBackground(new java.awt.Color(102, 102, 102));
        excluirHospFuncaoBtn.setToolTipText("");
        excluirHospFuncaoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        excluirHospFuncaoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                excluirHospFuncaoBtnMouseClicked(evt);
            }
        });
        excluirHospFuncaoBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel18.setBackground(new java.awt.Color(204, 204, 204));
        jPanel18.setPreferredSize(new java.awt.Dimension(3, 100));
        excluirHospFuncaoBtn.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        excluirHospFuncao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        excluirHospFuncao.setForeground(new java.awt.Color(255, 255, 255));
        excluirHospFuncao.setText("Excluir Hóspede");
        excluirHospFuncaoBtn.add(excluirHospFuncao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 30));

        FuncoesAbas.add(excluirHospFuncaoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 230, 40));

        excluirFuncFuncaoBtn.setBackground(new java.awt.Color(102, 102, 102));
        excluirFuncFuncaoBtn.setToolTipText("");
        excluirFuncFuncaoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        excluirFuncFuncaoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                excluirFuncFuncaoBtnMouseClicked(evt);
            }
        });
        excluirFuncFuncaoBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel20.setBackground(new java.awt.Color(204, 204, 204));
        jPanel20.setPreferredSize(new java.awt.Dimension(3, 100));
        excluirFuncFuncaoBtn.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        excluirFuncFuncao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        excluirFuncFuncao.setForeground(new java.awt.Color(255, 255, 255));
        excluirFuncFuncao.setText("Excluir Funcionários");
        excluirFuncFuncaoBtn.add(excluirFuncFuncao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 30));

        FuncoesAbas.add(excluirFuncFuncaoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 230, 40));

        verFuncFuncaoBtn.setBackground(new java.awt.Color(102, 102, 102));
        verFuncFuncaoBtn.setToolTipText("");
        verFuncFuncaoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verFuncFuncaoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verFuncFuncaoBtnMouseClicked(evt);
            }
        });
        verFuncFuncaoBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel19.setBackground(new java.awt.Color(204, 204, 204));
        jPanel19.setPreferredSize(new java.awt.Dimension(3, 100));
        verFuncFuncaoBtn.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        verFuncFuncao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        verFuncFuncao.setForeground(new java.awt.Color(255, 255, 255));
        verFuncFuncao.setText("Ver Funcionários");
        verFuncFuncaoBtn.add(verFuncFuncao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 30));

        FuncoesAbas.add(verFuncFuncaoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 230, 40));

        verHospFuncaoBtn.setBackground(new java.awt.Color(102, 102, 102));
        verHospFuncaoBtn.setToolTipText("");
        verHospFuncaoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verHospFuncaoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verHospFuncaoBtnMouseClicked(evt);
            }
        });
        verHospFuncaoBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel16.setBackground(new java.awt.Color(204, 204, 204));
        jPanel16.setPreferredSize(new java.awt.Dimension(3, 100));
        verHospFuncaoBtn.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        verHospFuncao.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        verHospFuncao.setForeground(new java.awt.Color(255, 255, 255));
        verHospFuncao.setText("Ver Hóspedes");
        verHospFuncaoBtn.add(verHospFuncao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 30));

        FuncoesAbas.add(verHospFuncaoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 230, 40));

        getContentPane().add(FuncoesAbas, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 230, 550));

        PanelPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        PanelPrincipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelInicio.setBackground(new java.awt.Color(245, 245, 245));
        panelInicio.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        iInicio.setBackground(new java.awt.Color(0, 0, 0));
        iInicio.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        iInicio.setForeground(new java.awt.Color(0, 102, 255));
        iInicio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iInicio.setText("Bem Vindo!");
        panelInicio.add(iInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 690, -1));

        PanelPrincipal.add(panelInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 710, 520));

        panelFuncionario.setBackground(new java.awt.Color(245, 245, 245));
        panelFuncionario.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarFuncionario.setBackground(new java.awt.Color(255, 255, 255));
        cadastrarFuncionario.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarNovoFuncionario.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cadastrarNovoFuncionario.setForeground(new java.awt.Color(0, 93, 187));
        cadastrarNovoFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cadastrarNovoFuncionario.setText("Cadastrar novo funcionário");
        cadastrarFuncionario.add(cadastrarNovoFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 710, -1));

        nomeFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        nomeFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        nomeFuncionario.setText("Nome");
        cadastrarFuncionario.add(nomeFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 128, 30));

        nomeFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        nomeFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nomeFuncionarioTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nomeFuncionarioTxtKeyTyped(evt);
            }
        });
        cadastrarFuncionario.add(nomeFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 360, 30));

        sexoFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        sexoFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        sexoFuncionario.setText("Sexo");
        cadastrarFuncionario.add(sexoFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 128, 30));

        sexoFuncionarioTxt.setBackground(new java.awt.Color(0, 93, 187));
        sexoFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        sexoFuncionarioTxt.setForeground(new java.awt.Color(255, 255, 255));
        sexoFuncionarioTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "F", "M" }));
        sexoFuncionarioTxt.setBorder(new javax.swing.border.MatteBorder(null));
        sexoFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                sexoFuncionarioTxtKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(sexoFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, 40, 30));

        nascimentoFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        nascimentoFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        nascimentoFuncionario.setText("Nascimento");
        cadastrarFuncionario.add(nascimentoFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 90, -1, 30));

        anoNascFuncionarioTxt.setBackground(new java.awt.Color(0, 93, 187));
        anoNascFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        anoNascFuncionarioTxt.setForeground(new java.awt.Color(255, 255, 255));
        anoNascFuncionarioTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900" }));
        anoNascFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                anoNascFuncionarioTxtKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(anoNascFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 90, 60, 30));

        diaNascFuncionarioTxt.setBackground(new java.awt.Color(0, 93, 187));
        diaNascFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        diaNascFuncionarioTxt.setForeground(new java.awt.Color(255, 255, 255));
        diaNascFuncionarioTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        diaNascFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                diaNascFuncionarioTxtKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(diaNascFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, -1, 30));

        mesNascFuncionarioTxt.setBackground(new java.awt.Color(0, 93, 187));
        mesNascFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mesNascFuncionarioTxt.setForeground(new java.awt.Color(255, 255, 255));
        mesNascFuncionarioTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        mesNascFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mesNascFuncionarioTxtKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(mesNascFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 90, -1, 30));

        rgFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rgFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        rgFuncionario.setText("RG");
        cadastrarFuncionario.add(rgFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 128, 30));

        rgFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rgFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rgFuncionarioTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rgFuncionarioTxtKeyTyped(evt);
            }
        });
        cadastrarFuncionario.add(rgFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 130, 360, 30));

        cpfFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cpfFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        cpfFuncionario.setText("CPF");
        cadastrarFuncionario.add(cpfFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 128, 30));

        cpfFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cpfFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cpfFuncionarioTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cpfFuncionarioTxtKeyTyped(evt);
            }
        });
        cadastrarFuncionario.add(cpfFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 170, 360, 30));

        emailFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        emailFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        emailFuncionario.setText("Email");
        cadastrarFuncionario.add(emailFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, 128, 30));

        emaiFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        emaiFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                emaiFuncionarioTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                emaiFuncionarioTxtKeyTyped(evt);
            }
        });
        cadastrarFuncionario.add(emaiFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 210, 360, 30));

        telefoneFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        telefoneFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        telefoneFuncionario.setText("Telefone");
        cadastrarFuncionario.add(telefoneFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, 128, 30));

        telefoneFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        telefoneFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                telefoneFuncionarioTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                telefoneFuncionarioTxtKeyTyped(evt);
            }
        });
        cadastrarFuncionario.add(telefoneFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, 360, 30));

        dataContratacaoFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        dataContratacaoFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        dataContratacaoFuncionario.setText("Data de Contratação");
        cadastrarFuncionario.add(dataContratacaoFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, -1, 30));

        diaConNovoFunc.setBackground(new java.awt.Color(0, 93, 187));
        diaConNovoFunc.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        diaConNovoFunc.setForeground(new java.awt.Color(255, 255, 255));
        diaConNovoFunc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        diaConNovoFunc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                diaConNovoFuncKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(diaConNovoFunc, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 330, -1, 30));

        mesConNovoFunc.setBackground(new java.awt.Color(0, 93, 187));
        mesConNovoFunc.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mesConNovoFunc.setForeground(new java.awt.Color(255, 255, 255));
        mesConNovoFunc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        mesConNovoFunc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mesConNovoFuncKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(mesConNovoFunc, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 330, -1, 30));

        anoConNovoFunc.setBackground(new java.awt.Color(0, 93, 187));
        anoConNovoFunc.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        anoConNovoFunc.setForeground(new java.awt.Color(255, 255, 255));
        anoConNovoFunc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900" }));
        anoConNovoFunc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                anoConNovoFuncKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(anoConNovoFunc, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 330, -1, 30));

        cargaHorariaFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cargaHorariaFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        cargaHorariaFuncionario.setText("Carga Horária Diária");
        cadastrarFuncionario.add(cargaHorariaFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 330, -1, 30));

        cargaHorariaFuncionarioTxt.setBackground(new java.awt.Color(0, 93, 187));
        cargaHorariaFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cargaHorariaFuncionarioTxt.setForeground(new java.awt.Color(255, 255, 255));
        cargaHorariaFuncionarioTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cargaHorariaFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cargaHorariaFuncionarioTxtKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(cargaHorariaFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 330, -1, 30));

        cargoFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cargoFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        cargoFuncionario.setText("Cargo");
        cadastrarFuncionario.add(cargoFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, 128, 30));

        cargoFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cargoFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cargoFuncionarioTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cargoFuncionarioTxtKeyTyped(evt);
            }
        });
        cadastrarFuncionario.add(cargoFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 370, 360, 30));

        enderecoFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        enderecoFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        enderecoFuncionario.setText("Endereço");
        cadastrarFuncionario.add(enderecoFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, 128, 30));

        enderecoFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        enderecoFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                enderecoFuncionarioTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                enderecoFuncionarioTxtKeyTyped(evt);
            }
        });
        cadastrarFuncionario.add(enderecoFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 290, 360, 30));

        cadastrarFuncionarioBtn.setBackground(new java.awt.Color(0, 93, 187));
        cadastrarFuncionarioBtn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cadastrarFuncionarioBtn.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarFuncionarioBtn.setText("Cadastrar");
        cadastrarFuncionarioBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cadastrarFuncionarioBtnMouseClicked(evt);
            }
        });
        cadastrarFuncionario.add(cadastrarFuncionarioBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 410, -1, 30));

        infoFuncionario.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        infoFuncionario.setText("*A data e a hora do cadastro é inserida automaticamente");
        cadastrarFuncionario.add(infoFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, -1, 20));

        erroFuncionario.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        erroFuncionario.setForeground(new java.awt.Color(255, 0, 0));
        erroFuncionario.setText("erro");
        cadastrarFuncionario.add(erroFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 460, 270, 20));

        usuarioFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        usuarioFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        usuarioFuncionario.setText("Usuário");
        cadastrarFuncionario.add(usuarioFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 410, 140, 30));

        usuarioFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        usuarioFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                usuarioFuncionarioTxtKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(usuarioFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 410, 130, 30));

        senhaFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        senhaFuncionario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        senhaFuncionario.setText("Senha");
        cadastrarFuncionario.add(senhaFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 410, 70, 30));

        senhaFuncionarioTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        senhaFuncionarioTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                senhaFuncionarioTxtKeyPressed(evt);
            }
        });
        cadastrarFuncionario.add(senhaFuncionarioTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 410, 130, 30));

        panelFuncionario.add(cadastrarFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, 500));

        PanelPrincipal.add(panelFuncionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 710, 500));

        panelHospede.setBackground(new java.awt.Color(245, 245, 245));
        panelHospede.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarHospede.setBackground(new java.awt.Color(255, 255, 255));
        cadastrarHospede.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarNovoHospede.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cadastrarNovoHospede.setForeground(new java.awt.Color(0, 93, 187));
        cadastrarNovoHospede.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cadastrarNovoHospede.setText("Cadastrar novo hóspede");
        cadastrarHospede.add(cadastrarNovoHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 710, -1));

        nomeHospede.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        nomeHospede.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        nomeHospede.setText("Nome");
        cadastrarHospede.add(nomeHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 130, 30));

        nomeHospedeTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        nomeHospedeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nomeHospedeTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nomeHospedeTxtKeyTyped(evt);
            }
        });
        cadastrarHospede.add(nomeHospedeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 120, 360, 30));

        sexoHospedeTxt.setBackground(new java.awt.Color(0, 93, 187));
        sexoHospedeTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        sexoHospedeTxt.setForeground(new java.awt.Color(255, 255, 255));
        sexoHospedeTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "F", "M" }));
        sexoHospedeTxt.setBorder(new javax.swing.border.MatteBorder(null));
        sexoHospedeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                sexoHospedeTxtKeyPressed(evt);
            }
        });
        cadastrarHospede.add(sexoHospedeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 160, 40, 30));

        sexoHospede.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        sexoHospede.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        sexoHospede.setText("Sexo");
        cadastrarHospede.add(sexoHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 128, 30));

        nascimentoHospede.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        nascimentoHospede.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        nascimentoHospede.setText("Nascimento");
        cadastrarHospede.add(nascimentoHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 160, -1, 30));

        diaNascHospedeTxt.setBackground(new java.awt.Color(0, 93, 187));
        diaNascHospedeTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        diaNascHospedeTxt.setForeground(new java.awt.Color(255, 255, 255));
        diaNascHospedeTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        diaNascHospedeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                diaNascHospedeTxtKeyPressed(evt);
            }
        });
        cadastrarHospede.add(diaNascHospedeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, -1, 30));

        mesNascHospedeTxt.setBackground(new java.awt.Color(0, 93, 187));
        mesNascHospedeTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mesNascHospedeTxt.setForeground(new java.awt.Color(255, 255, 255));
        mesNascHospedeTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        mesNascHospedeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mesNascHospedeTxtKeyPressed(evt);
            }
        });
        cadastrarHospede.add(mesNascHospedeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, -1, 30));

        anoNascHospedeTxt.setBackground(new java.awt.Color(0, 93, 187));
        anoNascHospedeTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        anoNascHospedeTxt.setForeground(new java.awt.Color(255, 255, 255));
        anoNascHospedeTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900" }));
        anoNascHospedeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                anoNascHospedeTxtKeyPressed(evt);
            }
        });
        cadastrarHospede.add(anoNascHospedeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 160, 60, 30));

        rgHospedeTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rgHospedeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rgHospedeTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rgHospedeTxtKeyTyped(evt);
            }
        });
        cadastrarHospede.add(rgHospedeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, 360, 30));

        rgHospede.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rgHospede.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        rgHospede.setText("RG");
        cadastrarHospede.add(rgHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 128, 30));

        cpfHospede.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cpfHospede.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        cpfHospede.setText("CPF");
        cadastrarHospede.add(cpfHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, 128, 30));

        cpfHospedeTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cpfHospedeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cpfHospedeTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cpfHospedeTxtKeyTyped(evt);
            }
        });
        cadastrarHospede.add(cpfHospedeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 240, 360, 30));

        telefoneHospede.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        telefoneHospede.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        telefoneHospede.setText("Telefone");
        cadastrarHospede.add(telefoneHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, 128, 30));

        telefoneHospedeTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        telefoneHospedeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                telefoneHospedeTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                telefoneHospedeTxtKeyTyped(evt);
            }
        });
        cadastrarHospede.add(telefoneHospedeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 360, 30));

        cadastrarHospedeBtn.setBackground(new java.awt.Color(0, 93, 187));
        cadastrarHospedeBtn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cadastrarHospedeBtn.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarHospedeBtn.setText("Cadastrar");
        cadastrarHospedeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cadastrarHospedeBtnMouseClicked(evt);
            }
        });
        cadastrarHospede.add(cadastrarHospedeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 410, -1, 30));

        cidadeHospede.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cidadeHospede.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        cidadeHospede.setText("Cidade");
        cadastrarHospede.add(cidadeHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, 130, 30));

        cidadeHospedeTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cadastrarHospede.add(cidadeHospedeTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 320, 360, 30));

        erroHospede.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        erroHospede.setForeground(new java.awt.Color(255, 0, 0));
        cadastrarHospede.add(erroHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 370, 360, 20));

        panelHospede.add(cadastrarHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, 500));

        PanelPrincipal.add(panelHospede, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 710, 500));

        panelQuarto.setBackground(new java.awt.Color(245, 245, 245));
        panelQuarto.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarQuarto.setBackground(new java.awt.Color(255, 255, 255));
        cadastrarQuarto.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarNovoQuarto.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cadastrarNovoQuarto.setForeground(new java.awt.Color(0, 93, 187));
        cadastrarNovoQuarto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cadastrarNovoQuarto.setText("Cadastrar novo quarto");
        cadastrarQuarto.add(cadastrarNovoQuarto, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 710, -1));

        numQuarto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        numQuarto.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        numQuarto.setText("Nº do quarto");
        cadastrarQuarto.add(numQuarto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 128, 30));

        numQuartoTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        numQuartoTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                numQuartoTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                numQuartoTxtKeyTyped(evt);
            }
        });
        cadastrarQuarto.add(numQuartoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 150, 130, 30));

        andarQuarto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        andarQuarto.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        andarQuarto.setText("Andar");
        cadastrarQuarto.add(andarQuarto, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 150, 50, 30));

        andarQuartoTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        andarQuartoTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                andarQuartoTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                andarQuartoTxtKeyTyped(evt);
            }
        });
        cadastrarQuarto.add(andarQuartoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 150, 130, 30));

        tipoQuarto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tipoQuarto.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tipoQuarto.setText("Tipo");
        cadastrarQuarto.add(tipoQuarto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, 128, 30));

        tipoQuartoTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tipoQuartoTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tipoQuartoTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tipoQuartoTxtKeyTyped(evt);
            }
        });
        cadastrarQuarto.add(tipoQuartoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, 360, 30));

        descricaoQuarto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        descricaoQuarto.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        descricaoQuarto.setText("Descrição");
        cadastrarQuarto.add(descricaoQuarto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, 128, 30));

        descricaoQuartoTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        descricaoQuartoTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                descricaoQuartoTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                descricaoQuartoTxtKeyTyped(evt);
            }
        });
        cadastrarQuarto.add(descricaoQuartoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 300, 360, 30));

        precoQuarto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        precoQuarto.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        precoQuarto.setText("Preço R$");
        cadastrarQuarto.add(precoQuarto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 130, 30));

        precoQuartoTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        precoQuartoTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                precoQuartoTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                precoQuartoTxtKeyTyped(evt);
            }
        });
        cadastrarQuarto.add(precoQuartoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, 130, 30));

        cadastrarQuartoBtn.setBackground(new java.awt.Color(0, 93, 187));
        cadastrarQuartoBtn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cadastrarQuartoBtn.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarQuartoBtn.setText("Cadastrar");
        cadastrarQuartoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cadastrarQuartoBtnMouseClicked(evt);
            }
        });
        cadastrarQuarto.add(cadastrarQuartoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 410, -1, 30));

        erroQuarto.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        erroQuarto.setForeground(new java.awt.Color(255, 0, 0));
        erroQuarto.setText("erro");
        cadastrarQuarto.add(erroQuarto, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, 360, 20));

        panelQuarto.add(cadastrarQuarto, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, 500));

        PanelPrincipal.add(panelQuarto, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 710, 500));

        panelReserva.setBackground(new java.awt.Color(245, 245, 245));
        panelReserva.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarReserva.setBackground(new java.awt.Color(255, 255, 255));
        cadastrarReserva.setMaximumSize(new java.awt.Dimension(710, 480));
        cadastrarReserva.setMinimumSize(new java.awt.Dimension(710, 480));
        cadastrarReserva.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarNovaReserva.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cadastrarNovaReserva.setForeground(new java.awt.Color(0, 93, 187));
        cadastrarNovaReserva.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cadastrarNovaReserva.setText("Cadastrar nova reserva");
        cadastrarReserva.add(cadastrarNovaReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 710, -1));

        numQuartoReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        numQuartoReserva.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        numQuartoReserva.setText("Nº do quarto");
        cadastrarReserva.add(numQuartoReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 90, 30));

        numQuartoReservaTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        numQuartoReservaTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                numQuartoReservaTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                numQuartoReservaTxtKeyTyped(evt);
            }
        });
        cadastrarReserva.add(numQuartoReservaTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, 90, 30));

        consumoReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        consumoReserva.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        consumoReserva.setText("Consumo  R$");
        cadastrarReserva.add(consumoReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, 90, 30));

        consumoReservaTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        consumoReservaTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                consumoReservaTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                consumoReservaTxtKeyTyped(evt);
            }
        });
        cadastrarReserva.add(consumoReservaTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 90, 30));

        estadoReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        estadoReserva.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        estadoReserva.setText("Estado");
        cadastrarReserva.add(estadoReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 300, 50, 30));

        idHospedeReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        idHospedeReserva.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        idHospedeReserva.setText("ID do Hóspede");
        cadastrarReserva.add(idHospedeReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, 100, 30));

        idHospedeReservaTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        idHospedeReservaTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                idHospedeReservaTxtKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                idHospedeReservaTxtKeyTyped(evt);
            }
        });
        cadastrarReserva.add(idHospedeReservaTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 350, 90, 30));

        dataEntradaReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        dataEntradaReserva.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        dataEntradaReserva.setText("Data de Entrada");
        cadastrarReserva.add(dataEntradaReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 350, 110, 30));

        estadoReservaTxt.setBackground(new java.awt.Color(0, 93, 187));
        estadoReservaTxt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        estadoReservaTxt.setForeground(new java.awt.Color(255, 255, 255));
        estadoReservaTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Reservado", "Em estadia", "Concluído" }));
        estadoReservaTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                estadoReservaTxtKeyPressed(evt);
            }
        });
        cadastrarReserva.add(estadoReservaTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 300, 180, 30));

        mesEntradaReserva.setBackground(new java.awt.Color(0, 93, 187));
        mesEntradaReserva.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mesEntradaReserva.setForeground(new java.awt.Color(255, 255, 255));
        mesEntradaReserva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        mesEntradaReserva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mesEntradaReservaKeyPressed(evt);
            }
        });
        cadastrarReserva.add(mesEntradaReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 350, 50, 30));

        anoEntradaReserva.setBackground(new java.awt.Color(0, 93, 187));
        anoEntradaReserva.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        anoEntradaReserva.setForeground(new java.awt.Color(255, 255, 255));
        anoEntradaReserva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900" }));
        anoEntradaReserva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                anoEntradaReservaKeyPressed(evt);
            }
        });
        cadastrarReserva.add(anoEntradaReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 350, 60, 30));

        verQuartoBtn.setBackground(new java.awt.Color(0, 93, 187));
        verQuartoBtn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        verQuartoBtn.setForeground(new java.awt.Color(255, 255, 255));
        verQuartoBtn.setText("Ver");
        verQuartoBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verQuartoBtnMouseClicked(evt);
            }
        });
        cadastrarReserva.add(verQuartoBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 300, 60, 30));

        dataSaidaReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        dataSaidaReserva.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        dataSaidaReserva.setText("Data de Saída");
        cadastrarReserva.add(dataSaidaReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 400, 90, 30));

        diaSaidaReserva.setBackground(new java.awt.Color(0, 93, 187));
        diaSaidaReserva.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        diaSaidaReserva.setForeground(new java.awt.Color(255, 255, 255));
        diaSaidaReserva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        diaSaidaReserva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                diaSaidaReservaKeyPressed(evt);
            }
        });
        cadastrarReserva.add(diaSaidaReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 400, 50, 30));

        mesSaidaReserva.setBackground(new java.awt.Color(0, 93, 187));
        mesSaidaReserva.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mesSaidaReserva.setForeground(new java.awt.Color(255, 255, 255));
        mesSaidaReserva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        mesSaidaReserva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mesSaidaReservaKeyPressed(evt);
            }
        });
        cadastrarReserva.add(mesSaidaReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 400, 50, 30));

        anoSaidaReserva.setBackground(new java.awt.Color(0, 93, 187));
        anoSaidaReserva.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        anoSaidaReserva.setForeground(new java.awt.Color(255, 255, 255));
        anoSaidaReserva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900" }));
        anoSaidaReserva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                anoSaidaReservaKeyPressed(evt);
            }
        });
        cadastrarReserva.add(anoSaidaReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 400, 60, 30));

        erroReserva.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        erroReserva.setForeground(new java.awt.Color(255, 0, 0));
        erroReserva.setText("erro");
        cadastrarReserva.add(erroReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 440, 260, -1));

        diaEntradaReserva1.setBackground(new java.awt.Color(0, 93, 187));
        diaEntradaReserva1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        diaEntradaReserva1.setForeground(new java.awt.Color(255, 255, 255));
        diaEntradaReserva1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        diaEntradaReserva1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                diaEntradaReserva1KeyPressed(evt);
            }
        });
        cadastrarReserva.add(diaEntradaReserva1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 350, 50, 30));

        cadastrarReservaBtn.setBackground(new java.awt.Color(0, 93, 187));
        cadastrarReservaBtn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cadastrarReservaBtn.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarReservaBtn.setText("Cadastrar");
        cadastrarReservaBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cadastrarReservaBtnMouseClicked(evt);
            }
        });
        cadastrarReserva.add(cadastrarReservaBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 400, -1, 30));

        selectHospedeReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        selectHospedeReserva.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Sexo", "Nasc", "CPF", "RG", "Telefone", "Cidade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        selectHospedeReserva.getTableHeader().setReorderingAllowed(false);
        selectHospedeReserva.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selectHospedeReservaMouseClicked(evt);
            }
        });
        selectHospedesReservas.setViewportView(selectHospedeReserva);
        if (selectHospedeReserva.getColumnModel().getColumnCount() > 0) {
            selectHospedeReserva.getColumnModel().getColumn(0).setResizable(false);
            selectHospedeReserva.getColumnModel().getColumn(0).setPreferredWidth(26);
            selectHospedeReserva.getColumnModel().getColumn(1).setResizable(false);
            selectHospedeReserva.getColumnModel().getColumn(2).setResizable(false);
            selectHospedeReserva.getColumnModel().getColumn(3).setResizable(false);
            selectHospedeReserva.getColumnModel().getColumn(4).setResizable(false);
            selectHospedeReserva.getColumnModel().getColumn(5).setResizable(false);
            selectHospedeReserva.getColumnModel().getColumn(6).setResizable(false);
            selectHospedeReserva.getColumnModel().getColumn(7).setResizable(false);
        }

        cadastrarReserva.add(selectHospedesReservas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 460, 210));

        infoSelectReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        infoSelectReserva.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        infoSelectReserva.setText("Descrição do Quarto");
        infoSelectReserva.setToolTipText("");
        cadastrarReserva.add(infoSelectReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 70, 220, 30));

        descricaoQuartoReserva.setEditable(false);
        descricaoQuartoReserva.setBorder(null);
        descricaoQuartoReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        descricaoQuartosReservas.setViewportView(descricaoQuartoReserva);

        cadastrarReserva.add(descricaoQuartosReservas, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 100, 220, 180));

        selectQuartoReserva.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        selectQuartoReserva.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nº", "Andar", "Preço", "Tipo", ""
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        selectQuartoReserva.getTableHeader().setReorderingAllowed(false);
        selectQuartoReserva.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selectQuartoReservaMouseClicked(evt);
            }
        });
        selectQuartosReservas.setViewportView(selectQuartoReserva);
        if (selectQuartoReserva.getColumnModel().getColumnCount() > 0) {
            selectQuartoReserva.getColumnModel().getColumn(0).setResizable(false);
            selectQuartoReserva.getColumnModel().getColumn(0).setPreferredWidth(26);
            selectQuartoReserva.getColumnModel().getColumn(1).setResizable(false);
            selectQuartoReserva.getColumnModel().getColumn(2).setResizable(false);
            selectQuartoReserva.getColumnModel().getColumn(3).setResizable(false);
            selectQuartoReserva.getColumnModel().getColumn(4).setResizable(false);
            selectQuartoReserva.getColumnModel().getColumn(4).setPreferredWidth(0);
        }

        cadastrarReserva.add(selectQuartosReservas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 460, 210));

        verHospedeBtn.setBackground(new java.awt.Color(0, 93, 187));
        verHospedeBtn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        verHospedeBtn.setForeground(new java.awt.Color(255, 255, 255));
        verHospedeBtn.setText("Ver");
        verHospedeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verHospedeBtnMouseClicked(evt);
            }
        });
        verHospedeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verHospedeBtnActionPerformed(evt);
            }
        });
        cadastrarReserva.add(verHospedeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 350, 60, 30));

        panelReserva.add(cadastrarReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, 500));

        PanelPrincipal.add(panelReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 710, 500));

        panelPagamento.setBackground(new java.awt.Color(245, 245, 245));
        panelPagamento.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarPagamento.setBackground(new java.awt.Color(255, 255, 255));
        cadastrarPagamento.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cadastrarNovoPag.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        cadastrarNovoPag.setForeground(new java.awt.Color(0, 93, 187));
        cadastrarNovoPag.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cadastrarNovoPag.setText("Cadastrar novo pagamento");
        cadastrarPagamento.add(cadastrarNovoPag, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 710, -1));

        valorPag.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        valorPag.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        valorPag.setText("Valor R$");
        cadastrarPagamento.add(valorPag, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 140, 60, 30));

        valorPagTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        valorPagTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                valorPagTxtKeyPressed(evt);
            }
        });
        cadastrarPagamento.add(valorPagTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 140, 90, 30));

        idFluxoPag.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        idFluxoPag.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        idFluxoPag.setText("idFluxo");
        cadastrarPagamento.add(idFluxoPag, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 140, 60, 30));

        idFluxoPagTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        idFluxoPagTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                idFluxoPagTxtKeyPressed(evt);
            }
        });
        cadastrarPagamento.add(idFluxoPagTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 140, 90, 30));

        dataPag.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        dataPag.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        dataPag.setText("Data");
        cadastrarPagamento.add(dataPag, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 190, 60, 30));

        diaPag.setBackground(new java.awt.Color(0, 93, 187));
        diaPag.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        diaPag.setForeground(new java.awt.Color(255, 255, 255));
        diaPag.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        diaPag.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                diaPagKeyPressed(evt);
            }
        });
        cadastrarPagamento.add(diaPag, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 190, 50, 30));

        mesPag.setBackground(new java.awt.Color(0, 93, 187));
        mesPag.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mesPag.setForeground(new java.awt.Color(255, 255, 255));
        mesPag.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        mesPag.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mesPagKeyPressed(evt);
            }
        });
        cadastrarPagamento.add(mesPag, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 190, 50, 30));

        anoPag.setBackground(new java.awt.Color(0, 93, 187));
        anoPag.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        anoPag.setForeground(new java.awt.Color(255, 255, 255));
        anoPag.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900" }));
        anoPag.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                anoPagKeyPressed(evt);
            }
        });
        cadastrarPagamento.add(anoPag, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 190, 60, 30));

        formaPag.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        formaPag.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        formaPag.setText("Forma de Pagamento");
        cadastrarPagamento.add(formaPag, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, 140, 30));

        formaPagTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        formaPagTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formaPagTxtKeyPressed(evt);
            }
        });
        cadastrarPagamento.add(formaPagTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 240, 290, 30));

        cadastrarPagBtn.setBackground(new java.awt.Color(0, 93, 187));
        cadastrarPagBtn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cadastrarPagBtn.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarPagBtn.setText("Cadastrar");
        cadastrarPagBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cadastrarPagBtnMouseClicked(evt);
            }
        });
        cadastrarPagBtn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cadastrarPagBtnKeyPressed(evt);
            }
        });
        cadastrarPagamento.add(cadastrarPagBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 410, -1, 30));

        erroPag.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        erroPag.setForeground(new java.awt.Color(255, 0, 0));
        erroPag.setText("erro");
        cadastrarPagamento.add(erroPag, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 440, 310, -1));

        panelPagamento.add(cadastrarPagamento, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, 500));

        PanelPrincipal.add(panelPagamento, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 710, 500));

        pesquisarTxt.setBackground(new java.awt.Color(0, 93, 187));
        pesquisarTxt.setForeground(new java.awt.Color(255, 255, 255));
        pesquisarTxt.setBorder(null);
        PanelPrincipal.add(pesquisarTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 10, 160, 23));

        ipesquisarTxt.setBackground(new java.awt.Color(255, 255, 255));
        ipesquisarTxt.setForeground(new java.awt.Color(255, 255, 255));
        ipesquisarTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/icon-pesquisar.png"))); // NOI18N
        ipesquisarTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PanelPrincipal.add(ipesquisarTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 10, -1, -1));

        getContentPane().add(PanelPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 50, 710, 550));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void sairTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sairTxtMouseClicked
        System.exit(0);
    }//GEN-LAST:event_sairTxtMouseClicked

    private void minimizarTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizarTxtMouseClicked
        this.setState(1);
    }//GEN-LAST:event_minimizarTxtMouseClicked

    private void d(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d
        // TODO add your handling code here:
    }//GEN-LAST:event_d

    private void inicioBtn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inicioBtn1MouseClicked
        corBtnGeral();
        esconderPaiFilho();
        esconderBtnFuncoes();
        inicioBtn1.setBackground(new Color(0, 19, 39));
    }//GEN-LAST:event_inicioBtn1MouseClicked

    private void funcionarioBtn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_funcionarioBtn1MouseClicked
        corBtnGeral();//cor dos botoes gerais desativados
        funcionarioBtn1.setBackground(new Color(0, 19, 39));//cor do proprio botao geral de funcionarios
        esconderPaiFilho();//esconde os panel's principais
        esconderBtnFuncoes();//esconde os botoes de funções
        cadastrarFuncFuncaoBtn.setVisible(true);//botao de cadastrar novo funcionario visível
        verFuncFuncaoBtn.setVisible(true);//botao de excluir funcionarios visível
        excluirFuncFuncaoBtn.setVisible(true);//botão de excluir
        corBtnFuncoes();//cor dos botoes de funcoes fiam desativadas(cinza)
        //reset funcionarios
        sexoFuncionarioTxt.setSelectedIndex(0);
        anoNascFuncionarioTxt.setSelectedIndex(0);
        mesNascFuncionarioTxt.setSelectedIndex(0);
        diaNascFuncionarioTxt.setSelectedIndex(0);
        anoConNovoFunc.setSelectedIndex(0);
        mesConNovoFunc.setSelectedIndex(0);
        diaConNovoFunc.setSelectedIndex(0);
        cargaHorariaFuncionarioTxt.setSelectedIndex(0);
        usuarioFuncionarioTxt.setText("");
        senhaFuncionarioTxt.setText("");
        nomeFuncionarioTxt.setText("");
        rgFuncionarioTxt.setText("");
        cpfFuncionarioTxt.setText("");
        emaiFuncionarioTxt.setText("");
        telefoneFuncionarioTxt.setText("");
        cargoFuncionarioTxt.setText("");
        enderecoFuncionarioTxt.setText("");
    }//GEN-LAST:event_funcionarioBtn1MouseClicked

    private void hospedeBtn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hospedeBtn1MouseClicked
        corBtnGeral();//cores dos botões gerais ficam desativados(azul-escuro)
        esconderPaiFilho();//esconde todos os panel's pais e filhos
        esconderBtnFuncoes();//esconde os botões de funções
        hospedeBtn1.setBackground(new Color(0, 19, 39));//cor do próprio botão
        cadastrarHospFuncaoBtn.setVisible(true);//botão de cadastrar hospedes
        excluirHospFuncaoBtn.setVisible(true);//botão de excluir hospedes

        //reset hospedes
        sexoHospedeTxt.setSelectedIndex(0);
        anoNascHospedeTxt.setSelectedIndex(0);
        mesNascHospedeTxt.setSelectedIndex(0);
        diaNascHospedeTxt.setSelectedIndex(0);
        nomeHospedeTxt.setText("");
        rgHospedeTxt.setText("");
        cpfHospedeTxt.setText("");
        telefoneHospedeTxt.setText("");
        cidadeHospedeTxt.setText("");
    }//GEN-LAST:event_hospedeBtn1MouseClicked

    private void quartoBtn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_quartoBtn1MouseClicked
        corBtnGeral();
        esconderPaiFilho();
        esconderBtnFuncoes();
        panelQuarto.setVisible(true);
        cadastrarQuarto.setVisible(true);
        quartoBtn1.setBackground(new Color(0, 19, 39));
        //reset quartos
        numQuartoTxt.setText("");
        andarQuartoTxt.setText("");
        tipoQuartoTxt.setText("");
        descricaoQuartoTxt.setText("");
        precoQuartoTxt.setText("");
    }//GEN-LAST:event_quartoBtn1MouseClicked

    private void reservaBtn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reservaBtn1MouseClicked
        corBtnGeral();
        esconderPaiFilho();
        esconderBtnFuncoes();
        panelReserva.setVisible(true);
        cadastrarReserva.setVisible(true);
        reservaBtn1.setBackground(new Color(0, 19, 39));
        //reset reservas
        anoEntradaReserva.setSelectedIndex(0);
        mesEntradaReserva.setSelectedIndex(0);
        estadoReservaTxt.setSelectedIndex(0);
        anoSaidaReserva.setSelectedIndex(0);
        mesSaidaReserva.setSelectedIndex(0);
        diaSaidaReserva.setSelectedIndex(0);
        estadoReservaTxt.setSelectedIndex(0);
        numQuartoReservaTxt.setText("");
        consumoReservaTxt.setText("");
        idHospedeReservaTxt.setText("");
    }//GEN-LAST:event_reservaBtn1MouseClicked

    private void pagamentoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pagamentoBtnMouseClicked
        corBtnGeral();
        esconderPaiFilho();
        esconderBtnFuncoes();
        panelPagamento.setVisible(true);
        pagamentoBtn.setBackground(new Color(0, 19, 39));
        //reset pagamentos
        diaPag.setSelectedIndex(0);
        mesPag.setSelectedIndex(0);
        anoPag.setSelectedIndex(0);
        valorPagTxt.setText("");
        idFluxoPagTxt.setText("");
        formaPagTxt.setText("");
    }//GEN-LAST:event_pagamentoBtnMouseClicked

    private void nomeFuncionarioTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomeFuncionarioTxtKeyTyped
        String caracteres = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáàãâéèêíìóòôõúùûÁÀÃÂÉÈÊÍÌÓÒÔÕÚÙÛ";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_nomeFuncionarioTxtKeyTyped

    private void emaiFuncionarioTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emaiFuncionarioTxtKeyTyped
        String caracteres = "@.0987654321abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáàãâéèêíìóòôõúùûÁÀÃÂÉÈÊÍÌÓÒÔÕÚÙÛ";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_emaiFuncionarioTxtKeyTyped

    private void telefoneFuncionarioTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_telefoneFuncionarioTxtKeyTyped
        String caracteres = "0987654321-";
        if (!caracteres.contains(evt.getKeyChar() + "") || telefoneFuncionarioTxt.getText().length() >= 12) {
            evt.consume();
        } else {
            if (telefoneFuncionarioTxt.getText().length() == 7) {
                telefoneFuncionarioTxt.setText(telefoneFuncionarioTxt.getText() + "-");
            }
        }
    }//GEN-LAST:event_telefoneFuncionarioTxtKeyTyped

    private void rgFuncionarioTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rgFuncionarioTxtKeyTyped
        String caracteres = "0987654321.-";
        if (!caracteres.contains(evt.getKeyChar() + "") || rgFuncionarioTxt.getText().length() >= 12) {
            evt.consume();
        }
    }//GEN-LAST:event_rgFuncionarioTxtKeyTyped

    private void cpfFuncionarioTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cpfFuncionarioTxtKeyTyped
        String caracteres = "0987654321.-/";
        if (!caracteres.contains(evt.getKeyChar() + "") || cpfFuncionarioTxt.getText().length() >= 14) {
            evt.consume();
        }
    }//GEN-LAST:event_cpfFuncionarioTxtKeyTyped

    private void enderecoFuncionarioTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_enderecoFuncionarioTxtKeyTyped
        String caracteres = " .,º0987654321abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáàãâéèêíìóòôõúùûÁÀÃÂÉÈÊÍÌÓÒÔÕÚÙÛ";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_enderecoFuncionarioTxtKeyTyped

    private void cargoFuncionarioTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cargoFuncionarioTxtKeyTyped
        String caracteres = " 0987654321abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáàãâéèêíìóòôõúùûÁÀÃÂÉÈÊÍÌÓÒÔÕÚÙÛ";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_cargoFuncionarioTxtKeyTyped

    private void cadastrarFuncionarioBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarFuncionarioBtnMouseClicked
        erroFuncionario.setText("");
        if (nomeFuncionarioTxt.getText().equals("") || rgFuncionarioTxt.getText().equals("") || cpfFuncionarioTxt.getText().equals("") || emaiFuncionarioTxt.getText().equals("") || telefoneFuncionarioTxt.getText().equals("") || enderecoFuncionarioTxt.getText().equals("") || cargoFuncionarioTxt.getText().equals("") || usuarioFuncionarioTxt.getText().equals("") || senhaFuncionarioTxt.getText().equals("")) {
            erroFuncionario.setText("Um ou mais campos foram deixados vazios!");
            System.out.println("Um ou mais campos foram deixados vazios!");

        } else if ((cpfFuncionarioTxt.getText().length() > 14 || cpfFuncionarioTxt.getText().length() < 11) && (rgFuncionarioTxt.getText().length() > 12 || rgFuncionarioTxt.getText().length() < 9)) {
            erroFuncionario.setText("Campo RG e CPF não foram preenchidos corretamente!");
            System.out.println("Campo RG e CPF não foram preenchidos corretamente!");

        } else if (rgFuncionarioTxt.getText().length() > 12 || rgFuncionarioTxt.getText().length() < 9) {
            erroFuncionario.setText("Campo RG não foi preenchido corretamente!");
            System.out.println("Campo RG não foi preenchido corretamente!");

        } else if (cpfFuncionarioTxt.getText().length() > 14 || cpfFuncionarioTxt.getText().length() < 11) {
            erroFuncionario.setText("Campo CPF não foi preenchido corretamente!");
            System.out.println("Campo CPF não foi preenchido corretamente!");

        } else {
            Funcionario f = new Funcionario();
            f.nome = nomeFuncionarioTxt.getText().replace("'", "");
            f.sexo = (String) sexoFuncionarioTxt.getSelectedItem();
            f.nascimento = (String) anoNascFuncionarioTxt.getSelectedItem() + "-" + (String) mesNascFuncionarioTxt.getSelectedItem() + "-" + (String) diaNascFuncionarioTxt.getSelectedItem();
            f.rg = rgFuncionarioTxt.getText().replace("'", "");
            f.cpf = cpfFuncionarioTxt.getText().replace("'", "");
            f.email = emaiFuncionarioTxt.getText().replace("'", "");
            f.telefone = telefoneFuncionarioTxt.getText().replace("'", "");
            f.endereco = enderecoFuncionarioTxt.getText().replace("'", "");
            f.dataContratacao = (String) anoConNovoFunc.getSelectedItem() + "-" + (String) mesConNovoFunc.getSelectedItem() + "-" + (String) diaConNovoFunc.getSelectedItem();
            f.cargaHoraria = (String) cargaHorariaFuncionarioTxt.getSelectedItem();
            f.cargo = cargoFuncionarioTxt.getText().replace("'", "");
            f.usuario = usuarioFuncionarioTxt.getText().replace("'", "");
            f.senha = senhaFuncionarioTxt.getText().replace("'", "");
            f.gravar();
        }
    }//GEN-LAST:event_cadastrarFuncionarioBtnMouseClicked

    private void nomeFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomeFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            sexoFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_nomeFuncionarioTxtKeyPressed

    private void sexoFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sexoFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            diaNascFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_sexoFuncionarioTxtKeyPressed

    private void mesNascFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mesNascFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            anoNascFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_mesNascFuncionarioTxtKeyPressed

    private void diaNascFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_diaNascFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            mesNascFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_diaNascFuncionarioTxtKeyPressed

    private void anoNascFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_anoNascFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            rgFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_anoNascFuncionarioTxtKeyPressed

    private void cpfFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cpfFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            emaiFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_cpfFuncionarioTxtKeyPressed

    private void rgFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rgFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            cpfFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_rgFuncionarioTxtKeyPressed

    private void emaiFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emaiFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            telefoneFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_emaiFuncionarioTxtKeyPressed

    private void telefoneFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_telefoneFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            enderecoFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_telefoneFuncionarioTxtKeyPressed

    private void diaConNovoFuncKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_diaConNovoFuncKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            mesConNovoFunc.requestFocus();
        }
    }//GEN-LAST:event_diaConNovoFuncKeyPressed

    private void enderecoFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_enderecoFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            diaConNovoFunc.requestFocus();
        }
    }//GEN-LAST:event_enderecoFuncionarioTxtKeyPressed

    private void mesConNovoFuncKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mesConNovoFuncKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            anoConNovoFunc.requestFocus();
        }
    }//GEN-LAST:event_mesConNovoFuncKeyPressed

    private void anoConNovoFuncKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_anoConNovoFuncKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            cargaHorariaFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_anoConNovoFuncKeyPressed

    private void cargaHorariaFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cargaHorariaFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            cargoFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_cargaHorariaFuncionarioTxtKeyPressed

    private void cargoFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cargoFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            usuarioFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_cargoFuncionarioTxtKeyPressed

    private void nomeHospedeTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomeHospedeTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            sexoHospedeTxt.requestFocus();
        }
    }//GEN-LAST:event_nomeHospedeTxtKeyPressed

    private void nomeHospedeTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomeHospedeTxtKeyTyped
        String caracteres = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáàãâéèêíìóòôõúùûÁÀÃÂÉÈÊÍÌÓÒÔÕÚÙÛ";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_nomeHospedeTxtKeyTyped

    private void sexoHospedeTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sexoHospedeTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            diaNascHospedeTxt.requestFocus();
        }
    }//GEN-LAST:event_sexoHospedeTxtKeyPressed

    private void diaNascHospedeTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_diaNascHospedeTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            mesNascHospedeTxt.requestFocus();
        }
    }//GEN-LAST:event_diaNascHospedeTxtKeyPressed

    private void mesNascHospedeTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mesNascHospedeTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            anoNascHospedeTxt.requestFocus();
        }
    }//GEN-LAST:event_mesNascHospedeTxtKeyPressed

    private void anoNascHospedeTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_anoNascHospedeTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            rgHospedeTxt.requestFocus();
        }
    }//GEN-LAST:event_anoNascHospedeTxtKeyPressed

    private void rgHospedeTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rgHospedeTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            cpfHospedeTxt.requestFocus();
        }
    }//GEN-LAST:event_rgHospedeTxtKeyPressed

    private void rgHospedeTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rgHospedeTxtKeyTyped
        String caracteres = "0987654321.-";
        if (!caracteres.contains(evt.getKeyChar() + "") || rgHospedeTxt.getText().length() >= 12) {
            evt.consume();
        }
    }//GEN-LAST:event_rgHospedeTxtKeyTyped

    private void cpfHospedeTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cpfHospedeTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            telefoneHospedeTxt.requestFocus();
        }
    }//GEN-LAST:event_cpfHospedeTxtKeyPressed

    private void cpfHospedeTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cpfHospedeTxtKeyTyped
        String caracteres = "0987654321.-/";
        if (!caracteres.contains(evt.getKeyChar() + "") || cpfHospedeTxt.getText().length() >= 14) {
            evt.consume();
        }
    }//GEN-LAST:event_cpfHospedeTxtKeyTyped

    private void telefoneHospedeTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_telefoneHospedeTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            cadastrarHospedeBtn.requestFocus();
        }
    }//GEN-LAST:event_telefoneHospedeTxtKeyPressed

    private void telefoneHospedeTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_telefoneHospedeTxtKeyTyped
        String caracteres = "0987654321-";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        } else {
            if (telefoneHospedeTxt.getText().length() == 7) {
                telefoneHospedeTxt.setText(telefoneHospedeTxt.getText() + "-");
            }
        }
    }//GEN-LAST:event_telefoneHospedeTxtKeyTyped

    private void cadastrarHospedeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarHospedeBtnMouseClicked
        erroHospede.setText("");
        if (nomeHospedeTxt.getText().equals("") || rgHospedeTxt.getText().equals("") || cpfHospedeTxt.getText().equals("") || telefoneHospedeTxt.getText().equals("")) {
            erroHospede.setText("Um ou mais campos foram deixados vazios!");
            System.out.println("Um ou mais campos foram deixados vazios!");

        } else if (rgHospedeTxt.getText().length() > 12 || rgHospedeTxt.getText().length() < 9) {
            erroHospede.setText("Campo RG foi preenchido incorretamente!");
            System.out.println("Campo RG foi preenchido incorretamente!");

        } else if (cpfHospedeTxt.getText().length() > 14 || cpfHospedeTxt.getText().length() < 11) {
            erroHospede.setText("Campo CPF não foi preenchido corretamente!");
            System.out.println("Campo CPF não foi preenchido corretamente!");

        } else if ((cpfHospedeTxt.getText().length() > 14 || cpfHospedeTxt.getText().length() < 11) && (rgHospedeTxt.getText().length() > 12 || rgHospedeTxt.getText().length() < 9)) {
            erroHospede.setText("Campo CPF e RG foram preenchidos incorretamente!");
            System.out.println("Campo CPF e RG foram preenchidos incorretamente!");

        } else {
            Hospede f = new Hospede();
            f.nome = nomeHospedeTxt.getText().replace("'", "");
            f.sexo = (String) sexoHospedeTxt.getSelectedItem();
            f.nascimento = (String) anoNascHospedeTxt.getSelectedItem() + "-" + (String) mesNascHospedeTxt.getSelectedItem() + "-" + (String) diaNascHospedeTxt.getSelectedItem();
            f.rg = rgHospedeTxt.getText().replace("'", "");
            f.cpf = cpfHospedeTxt.getText().replace("'", "");
            f.telefone = telefoneFuncionarioTxt.getText().replace("'", "");
            f.cidade = cidadeHospedeTxt.getText().replace("'", "");
            f.gravar();
        }
    }//GEN-LAST:event_cadastrarHospedeBtnMouseClicked

    private void numQuartoTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numQuartoTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            andarQuartoTxt.requestFocus();
        }
    }//GEN-LAST:event_numQuartoTxtKeyPressed

    private void numQuartoTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numQuartoTxtKeyTyped
        String caracteres = "0987654321.-/";
        if (!caracteres.contains(evt.getKeyChar() + "") || numQuartoTxt.getText().length() >= 4) {
            evt.consume();
        }
    }//GEN-LAST:event_numQuartoTxtKeyTyped

    private void andarQuartoTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_andarQuartoTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            precoQuartoTxt.requestFocus();
        }
    }//GEN-LAST:event_andarQuartoTxtKeyPressed

    private void andarQuartoTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_andarQuartoTxtKeyTyped
        String caracteres = "0987654321.-/";
        if (!caracteres.contains(evt.getKeyChar() + "") || andarQuartoTxt.getText().length() >= 3) {
            evt.consume();
        }
    }//GEN-LAST:event_andarQuartoTxtKeyTyped

    private void tipoQuartoTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tipoQuartoTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            descricaoQuartoTxt.requestFocus();
        }
    }//GEN-LAST:event_tipoQuartoTxtKeyPressed

    private void tipoQuartoTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tipoQuartoTxtKeyTyped
        String caracteres = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáàãâéèêíìóòôõúùûÁÀÃÂÉÈÊÍÌÓÒÔÕÚÙÛ";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_tipoQuartoTxtKeyTyped

    private void precoQuartoTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_precoQuartoTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            tipoQuartoTxt.requestFocus();
        }
    }//GEN-LAST:event_precoQuartoTxtKeyPressed

    private void precoQuartoTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_precoQuartoTxtKeyTyped
        String caracteres = "0987654321.";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_precoQuartoTxtKeyTyped

    private void cadastrarQuartoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarQuartoBtnMouseClicked
        erroQuarto.setText("");
        if (numQuartoTxt.getText().equals("") || andarQuartoTxt.getText().equals("") || tipoQuartoTxt.getText().equals("") || descricaoQuartoTxt.getText().equals("") || precoQuartoTxt.getText().equals("")) {
            System.out.println("Um ou mais campos foram deixados vazios!");
            erroQuarto.setText("Um ou mais campos foram deixados vazios!");

        } else {
            Quarto q = new Quarto();
            q.numero = Integer.parseInt(numQuartoTxt.getText().replace("'", ""));
            q.andar = Integer.parseInt(andarQuartoTxt.getText().replace("'", ""));
            q.preco = Double.parseDouble(precoQuartoTxt.getText().replace("'", ""));
            q.tipo = tipoQuartoTxt.getText().replace("'", "");
            q.descricao = descricaoQuartoTxt.getText().replace("'", "");
            q.gravar();
            System.out.println("Gravando novo quarto no Banco de dados...");
        }
    }//GEN-LAST:event_cadastrarQuartoBtnMouseClicked

    private void numQuartoReservaTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numQuartoReservaTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            consumoReservaTxt.requestFocus();
        }
    }//GEN-LAST:event_numQuartoReservaTxtKeyPressed

    private void numQuartoReservaTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numQuartoReservaTxtKeyTyped
        String caracteres = "0987654321";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_numQuartoReservaTxtKeyTyped

    private void consumoReservaTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_consumoReservaTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            idHospedeReservaTxt.requestFocus();
        }
    }//GEN-LAST:event_consumoReservaTxtKeyPressed
    private void consumoReservaTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_consumoReservaTxtKeyTyped
        String caracteres = "0987654321.";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_consumoReservaTxtKeyTyped

    private void idHospedeReservaTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idHospedeReservaTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            estadoReservaTxt.requestFocus();
        }
    }//GEN-LAST:event_idHospedeReservaTxtKeyPressed

    private void idHospedeReservaTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idHospedeReservaTxtKeyTyped
        String caracteres = "0987654321";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_idHospedeReservaTxtKeyTyped

    private void estadoReservaTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_estadoReservaTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            mesEntradaReserva.requestFocus();
        }
    }//GEN-LAST:event_estadoReservaTxtKeyPressed

    private void mesEntradaReservaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mesEntradaReservaKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            anoEntradaReserva.requestFocus();
        }
    }//GEN-LAST:event_mesEntradaReservaKeyPressed

    private void anoEntradaReservaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_anoEntradaReservaKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            diaSaidaReserva.requestFocus();
        }
    }//GEN-LAST:event_anoEntradaReservaKeyPressed

    private void diaSaidaReservaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_diaSaidaReservaKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            mesSaidaReserva.requestFocus();
        }
    }//GEN-LAST:event_diaSaidaReservaKeyPressed

    private void mesSaidaReservaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mesSaidaReservaKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            anoSaidaReserva.requestFocus();
        }
    }//GEN-LAST:event_mesSaidaReservaKeyPressed

    private void anoSaidaReservaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_anoSaidaReservaKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            verQuartoBtn.requestFocus();
        }
    }//GEN-LAST:event_anoSaidaReservaKeyPressed

    private void descricaoQuartoTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_descricaoQuartoTxtKeyTyped
        String caracteres = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáàãâéèêíìóòôõúùûÁÀÃÂÉÈÊÍÌÓÒÔÕÚÙÛ";
        if (!caracteres.contains(evt.getKeyChar() + "")) {
            evt.consume();
        }
    }//GEN-LAST:event_descricaoQuartoTxtKeyTyped

    private void descricaoQuartoTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_descricaoQuartoTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            cadastrarQuartoBtn.requestFocus();
        }
    }//GEN-LAST:event_descricaoQuartoTxtKeyPressed

    private void diaPagKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_diaPagKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            mesPag.requestFocus();
        }
    }//GEN-LAST:event_diaPagKeyPressed

    private void mesPagKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mesPagKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            anoPag.requestFocus();
        }
    }//GEN-LAST:event_mesPagKeyPressed

    private void anoPagKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_anoPagKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            formaPagTxt.requestFocus();
        }
    }//GEN-LAST:event_anoPagKeyPressed

    private void cadastrarPagBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarPagBtnMouseClicked
        erroPag.setText("");
        if (idFluxoPagTxt.getText().equals("") || valorPagTxt.getText().equals("") || formaPagTxt.getText().equals("")) {
            System.out.println("Um ou mais campos foram deixados vazios!");
            erroPag.setText("Um ou mais campos foram deixados vazios!");

        } else {
            Pagamento p = new Pagamento();
            p.idFluxo = Integer.parseInt(idFluxoPagTxt.getText().replace("'", ""));
            p.valor = Double.parseDouble(valorPagTxt.getText().replace("'", ""));
            p.data = (String) anoPag.getSelectedItem() + "-" + (String) mesPag.getSelectedItem() + "-" + (String) diaPag.getSelectedItem();
            p.Fpagamento = formaPagTxt.getText().replace("'", "");
            p.gravar();
            System.out.println("Gravando novo quarto no Banco de dados...");
        }
    }//GEN-LAST:event_cadastrarPagBtnMouseClicked

    private void idFluxoPagTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idFluxoPagTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            valorPagTxt.requestFocus();
        }
    }//GEN-LAST:event_idFluxoPagTxtKeyPressed

    private void valorPagTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_valorPagTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            diaPag.requestFocus();
        }
    }//GEN-LAST:event_valorPagTxtKeyPressed

    private void formaPagTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formaPagTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            cadastrarPagBtn.requestFocus();
        }
    }//GEN-LAST:event_formaPagTxtKeyPressed

    private void cadastrarPagBtnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cadastrarPagBtnKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            erroPag.setText("");
            if (idFluxoPagTxt.getText().equals("") || valorPagTxt.getText().equals("") || formaPagTxt.getText().equals("")) {
                System.out.println("Um ou mais campos foram deixados vazios!");
                erroPag.setText("Um ou mais campos foram deixados vazios!");

            } else {
                Pagamento p = new Pagamento();
                p.idFluxo = Integer.parseInt(idFluxoPagTxt.getText().replace("'", ""));
                p.valor = Double.parseDouble(valorPagTxt.getText().replace("'", ""));
                p.data = (String) anoPag.getSelectedItem() + "-" + (String) mesPag.getSelectedItem() + "-" + (String) diaPag.getSelectedItem();
                p.Fpagamento = formaPagTxt.getText().replace("'", "");
                p.gravar();
                System.out.println("Gravando novo quarto no Banco de dados...");
            }
        }
    }//GEN-LAST:event_cadastrarPagBtnKeyPressed

    private void usuarioFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_usuarioFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            senhaFuncionarioTxt.requestFocus();
        }
    }//GEN-LAST:event_usuarioFuncionarioTxtKeyPressed

    private void senhaFuncionarioTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_senhaFuncionarioTxtKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            cadastrarFuncionarioBtn.requestFocus();
        }
    }//GEN-LAST:event_senhaFuncionarioTxtKeyPressed

    private void diaEntradaReserva1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_diaEntradaReserva1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_diaEntradaReserva1KeyPressed

    private void cadastrarReservaBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarReservaBtnMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_cadastrarReservaBtnMouseClicked

    private void verQuartoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verQuartoBtnMouseClicked
        selectHospedesReservas.setVisible(false);
        selectQuartosReservas.setVisible(true);
        descricaoQuartoReserva.setText("");
        infoSelectReserva.setText("Descrição do Quarto");
        selectQuartosJTable("SELECT numero,andar,preco,tipo,descricao FROM quartos WHERE disponivel = 'S';");
    }//GEN-LAST:event_verQuartoBtnMouseClicked

    private void selectHospedeReservaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selectHospedeReservaMouseClicked
        int linha = selectHospedeReserva.getSelectedRow();
        descricaoQuartoReserva.setText("CPF:   " + selectHospedeReserva.getValueAt(linha, 4).toString() + "\nRG:   " + selectHospedeReserva.getValueAt(linha, 5).toString() + "\nTelefone:   " + selectHospedeReserva.getValueAt(linha, 6).toString() + "\nCidade:   " + selectHospedeReserva.getValueAt(linha, 7).toString());
        idHospedeReservaTxt.setText(selectHospedeReserva.getValueAt(linha, 0).toString());
    }//GEN-LAST:event_selectHospedeReservaMouseClicked

    private void selectQuartoReservaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selectQuartoReservaMouseClicked
        int linha = selectQuartoReserva.getSelectedRow();
        descricaoQuartoReserva.setText(selectQuartoReserva.getValueAt(linha, 4).toString());
        numQuartoReservaTxt.setText(selectQuartoReserva.getValueAt(linha, 0).toString());
    }//GEN-LAST:event_selectQuartoReservaMouseClicked

    private void verHospedeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verHospedeBtnMouseClicked
        selectQuartosReservas.setVisible(false);
        selectHospedesReservas.setVisible(true);
        descricaoQuartoReserva.setText("");
        infoSelectReserva.setText("Informações do Hóspede");
        selectHospedesJTable("SELECT idHospede,nome,sexo,nascimento,cpf,rg,telefone,cidade FROM hospedes;");
    }//GEN-LAST:event_verHospedeBtnMouseClicked

    private void cadastrarFuncFuncaoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarFuncFuncaoBtnMouseClicked
        corBtnFuncoes();//esconde todos os panel's e chama a função corBtnFuncoes(); que defini a cor de todos os botões para desativado(cinza)
        esconderPaiFilho();//esconde todos os panel's pais e filhos
        cadastrarFuncFuncaoBtn.setVisible(true);//próprio botão visível
        cadastrarFuncFuncaoBtn.setBackground(new Color(255, 255, 255));//cor do próprio botão da função de cadastrar novo funcionario
        cadastrarFunciFuncao.setForeground(new Color(0, 0, 0));//cor do texto do botao da função de cadastrar novo funcionario
        panelFuncionario.setVisible(true);//panel pai
        cadastrarFuncionario.setVisible(true);//panel filho
    }//GEN-LAST:event_cadastrarFuncFuncaoBtnMouseClicked

    private void verHospFuncaoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verHospFuncaoBtnMouseClicked
        corBtnFuncoes();//cor dos botoes de funções desativadas(cinza)
        esconderPaiFilho();//esconde todos os panel's pais e filhos
        panelHospede.setVisible(true);//panel pai
        verHospedeBtn.setVisible(true);//panel filho
        verHospFuncaoBtn.setVisible(true);//próprio botão visível
        verHospFuncaoBtn.setBackground(new Color(255, 255, 255));//cor do próprio botão
        verHospFuncao.setForeground(new Color(0, 0, 0));//texto do próprio botao
    }//GEN-LAST:event_verHospFuncaoBtnMouseClicked

    private void cadastrarHospFuncaoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarHospFuncaoBtnMouseClicked
        corBtnFuncoes();//cor dos botoes de funções desativadas(cinza)
        esconderPaiFilho();//esconde todos os panel's pais e filhos
        panelHospede.setVisible(true);//panel pai
        cadastrarHospede.setVisible(true);//panel filho
        cadastrarHospFuncaoBtn.setVisible(true);//próprio botão visível
        cadastrarHospFuncaoBtn.setBackground(new Color(255, 255, 255));//cor do próprio botão
        cadastrarHospFuncao.setForeground(new Color(0, 0, 0));//texto do próprio botao
    }//GEN-LAST:event_cadastrarHospFuncaoBtnMouseClicked

    private void excluirHospFuncaoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_excluirHospFuncaoBtnMouseClicked
        corBtnFuncoes();//cor dos botoes de funções desativadas(cinza)
        esconderPaiFilho();//esconde todos os panel's pais e filhos
        panelHospede.setVisible(true);//panel pai
        //panelExcluir.setVisible(true);//panel filho
        excluirHospFuncaoBtn.setVisible(true);//próprio botão visível
        excluirHospFuncaoBtn.setBackground(new Color(255, 255, 255));//cor do próprio botão
        excluirHospFuncao.setForeground(new Color(0, 0, 0));//texto do próprio botao
    }//GEN-LAST:event_excluirHospFuncaoBtnMouseClicked

    private void verFuncFuncaoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verFuncFuncaoBtnMouseClicked
        corBtnFuncoes();//esconde todos os panel's e chama a função corBtnFuncoes(); que defini a cor de todos os botões para desativado(cinza)
        esconderPaiFilho();//esconde todos os panel's pais e filhos
        verFuncFuncaoBtn.setVisible(true);//próprio botão visível
        verFuncFuncaoBtn.setBackground(new Color(255, 255, 255));//cor do próprio botão da função de cadastrar novo funcionario
        verFuncFuncao.setForeground(new Color(0, 0, 0));//cor do texto do botao da função de cadastrar novo funcionario
        panelFuncionario.setVisible(true);//panel pai
        //verFuncionario.setVisible(true);//panel filho
    }//GEN-LAST:event_verFuncFuncaoBtnMouseClicked

    private void excluirFuncFuncaoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_excluirFuncFuncaoBtnMouseClicked
        corBtnFuncoes();//esconde todos os panel's e chama a função corBtnFuncoes(); que defini a cor de todos os botões para desativado(cinza)
        esconderPaiFilho();//esconde todos os panel's pais e filhos
        excluirFuncFuncaoBtn.setVisible(true);//próprio botão visível
        excluirFuncFuncaoBtn.setBackground(new Color(255, 255, 255));//cor do próprio botão da função de cadastrar novo funcionario
        excluirFuncFuncao.setForeground(new Color(0, 0, 0));//cor do texto do botao da função de cadastrar novo funcionario
        panelFuncionario.setVisible(true);//panel pai
        //excluirFuncionario.setVisible(true);//panel filho
    }//GEN-LAST:event_excluirFuncFuncaoBtnMouseClicked

    private void verHospedeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verHospedeBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_verHospedeBtnActionPerformed

    private void cadastrarQuaFuncaoBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cadastrarQuaFuncaoBtnMouseClicked
        corBtnFuncoes();//esconde todos os panel's e chama a função corBtnFuncoes(); que defini a cor de todos os botões para desativado(cinza)
        esconderPaiFilho();//esconde todos os panel's pais e filhos
        cadastrarQuaFuncaoBtn.setVisible(true);//próprio botão visível
        cadastrarQuaFuncaoBtn.setBackground(new Color(255, 255, 255));//cor do próprio botão da função de cadastrar novo funcionario
        cadastrarQuaFuncao.setForeground(new Color(0, 0, 0));//cor do texto do botao da função de cadastrar novo funcionario
        panelHospede.setVisible(true);//panel pai
        //excluirFuncionario.setVisible(true);//panel filho
    }//GEN-LAST:event_cadastrarQuaFuncaoBtnMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicial().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel FuncoesAbas;
    private javax.swing.JPanel PanelEsquerdo;
    private javax.swing.JPanel PanelPrincipal;
    private javax.swing.JPanel PanelTopo;
    private javax.swing.JLabel andarQuarto;
    private javax.swing.JTextField andarQuartoTxt;
    private javax.swing.JComboBox<String> anoConNovoFunc;
    private javax.swing.JComboBox<String> anoEntradaReserva;
    private javax.swing.JComboBox<String> anoNascFuncionarioTxt;
    private javax.swing.JComboBox<String> anoNascHospedeTxt;
    private javax.swing.JComboBox<String> anoPag;
    private javax.swing.JComboBox<String> anoSaidaReserva;
    private javax.swing.JLabel avisoTxt;
    private javax.swing.JPanel cadastrarFuncFuncaoBtn;
    private javax.swing.JLabel cadastrarFunciFuncao;
    private javax.swing.JPanel cadastrarFuncionario;
    private javax.swing.JButton cadastrarFuncionarioBtn;
    private javax.swing.JLabel cadastrarHospFuncao;
    private javax.swing.JPanel cadastrarHospFuncaoBtn;
    private javax.swing.JPanel cadastrarHospede;
    private javax.swing.JButton cadastrarHospedeBtn;
    private javax.swing.JLabel cadastrarNovaReserva;
    private javax.swing.JLabel cadastrarNovoFuncionario;
    private javax.swing.JLabel cadastrarNovoHospede;
    private javax.swing.JLabel cadastrarNovoPag;
    private javax.swing.JLabel cadastrarNovoQuarto;
    private javax.swing.JButton cadastrarPagBtn;
    private javax.swing.JPanel cadastrarPagamento;
    private javax.swing.JLabel cadastrarQuaFuncao;
    private javax.swing.JPanel cadastrarQuaFuncaoBtn;
    private javax.swing.JPanel cadastrarQuarto;
    private javax.swing.JButton cadastrarQuartoBtn;
    private javax.swing.JPanel cadastrarReserva;
    private javax.swing.JButton cadastrarReservaBtn;
    private javax.swing.JLabel calendarioTxt;
    private javax.swing.JLabel cargaHorariaFuncionario;
    private javax.swing.JComboBox<String> cargaHorariaFuncionarioTxt;
    private javax.swing.JLabel cargoFuncionario;
    private javax.swing.JTextField cargoFuncionarioTxt;
    private javax.swing.JLabel cidadeHospede;
    private javax.swing.JTextField cidadeHospedeTxt;
    private javax.swing.JLabel consumoReserva;
    private javax.swing.JTextField consumoReservaTxt;
    private javax.swing.JLabel cpfFuncionario;
    private javax.swing.JTextField cpfFuncionarioTxt;
    private javax.swing.JLabel cpfHospede;
    private javax.swing.JTextField cpfHospedeTxt;
    private javax.swing.JLabel dataContratacaoFuncionario;
    private javax.swing.JLabel dataEntradaReserva;
    private javax.swing.JLabel dataPag;
    private javax.swing.JLabel dataSaidaReserva;
    private javax.swing.JLabel descricaoQuarto;
    private javax.swing.JTextPane descricaoQuartoReserva;
    private javax.swing.JTextField descricaoQuartoTxt;
    private javax.swing.JScrollPane descricaoQuartosReservas;
    private javax.swing.JComboBox<String> diaConNovoFunc;
    private javax.swing.JComboBox<String> diaEntradaReserva1;
    private javax.swing.JComboBox<String> diaNascFuncionarioTxt;
    private javax.swing.JComboBox<String> diaNascHospedeTxt;
    private javax.swing.JComboBox<String> diaPag;
    private javax.swing.JComboBox<String> diaSaidaReserva;
    private javax.swing.JTextField emaiFuncionarioTxt;
    private javax.swing.JLabel emailFuncionario;
    private javax.swing.JLabel enderecoFuncionario;
    private javax.swing.JTextField enderecoFuncionarioTxt;
    private javax.swing.JLabel erroFuncionario;
    private javax.swing.JLabel erroHospede;
    private javax.swing.JLabel erroPag;
    private javax.swing.JLabel erroQuarto;
    private javax.swing.JLabel erroReserva;
    private javax.swing.JLabel estadoReserva;
    private javax.swing.JComboBox<String> estadoReservaTxt;
    private javax.swing.JLabel excluirFuncFuncao;
    private javax.swing.JPanel excluirFuncFuncaoBtn;
    private javax.swing.JLabel excluirHospFuncao;
    private javax.swing.JPanel excluirHospFuncaoBtn;
    private javax.swing.JLabel formaPag;
    private javax.swing.JTextField formaPagTxt;
    private javax.swing.JPanel funcionarioBtn1;
    private javax.swing.JLabel funcionarioTxt1;
    private javax.swing.JPanel hospedeBtn1;
    private javax.swing.JLabel hospedeTxt1;
    private javax.swing.JLabel iInicio;
    private javax.swing.JLabel iconHotelTxt;
    private javax.swing.JLabel idFluxoPag;
    private javax.swing.JTextField idFluxoPagTxt;
    private javax.swing.JLabel idHospedeReserva;
    private javax.swing.JTextField idHospedeReservaTxt;
    private javax.swing.JLabel infoFuncionario;
    private javax.swing.JLabel infoSelectReserva;
    private javax.swing.JPanel inicioBtn1;
    private javax.swing.JLabel inicioTxt1;
    private javax.swing.JLabel ipesquisarTxt;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JComboBox<String> mesConNovoFunc;
    private javax.swing.JComboBox<String> mesEntradaReserva;
    private javax.swing.JComboBox<String> mesNascFuncionarioTxt;
    private javax.swing.JComboBox<String> mesNascHospedeTxt;
    private javax.swing.JComboBox<String> mesPag;
    private javax.swing.JComboBox<String> mesSaidaReserva;
    private javax.swing.JLabel minimizarTxt;
    private javax.swing.JLabel nascimentoFuncionario;
    private javax.swing.JLabel nascimentoHospede;
    private javax.swing.JLabel nomeFuncionario;
    private javax.swing.JTextField nomeFuncionarioTxt;
    private javax.swing.JLabel nomeHospede;
    private javax.swing.JTextField nomeHospedeTxt;
    private javax.swing.JLabel numQuarto;
    private javax.swing.JLabel numQuartoReserva;
    private javax.swing.JTextField numQuartoReservaTxt;
    private javax.swing.JTextField numQuartoTxt;
    private javax.swing.JPanel pagamentoBtn;
    private javax.swing.JPanel panelFuncionario;
    private javax.swing.JPanel panelHospede;
    private javax.swing.JPanel panelInicio;
    private javax.swing.JPanel panelPagamento;
    private javax.swing.JPanel panelQuarto;
    private javax.swing.JPanel panelReserva;
    private javax.swing.JTextField pesquisarTxt;
    private javax.swing.JLabel precoQuarto;
    private javax.swing.JTextField precoQuartoTxt;
    private javax.swing.JPanel quartoBtn1;
    private javax.swing.JLabel quartoTxt1;
    private javax.swing.JPanel reservaBtn1;
    private javax.swing.JLabel reservaTxt1;
    private javax.swing.JLabel rgFuncionario;
    private javax.swing.JTextField rgFuncionarioTxt;
    private javax.swing.JLabel rgHospede;
    private javax.swing.JTextField rgHospedeTxt;
    private javax.swing.JLabel sairTxt;
    private javax.swing.JTable selectHospedeReserva;
    private javax.swing.JScrollPane selectHospedesReservas;
    private javax.swing.JTable selectQuartoReserva;
    private javax.swing.JScrollPane selectQuartosReservas;
    private javax.swing.JLabel senhaFuncionario;
    private javax.swing.JTextField senhaFuncionarioTxt;
    private javax.swing.JLabel sexoFuncionario;
    private javax.swing.JComboBox<String> sexoFuncionarioTxt;
    private javax.swing.JLabel sexoHospede;
    private javax.swing.JComboBox<String> sexoHospedeTxt;
    private javax.swing.JLabel telefoneFuncionario;
    private javax.swing.JTextField telefoneFuncionarioTxt;
    private javax.swing.JLabel telefoneHospede;
    private javax.swing.JTextField telefoneHospedeTxt;
    private javax.swing.JLabel tipoQuarto;
    private javax.swing.JTextField tipoQuartoTxt;
    private javax.swing.JLabel titleSoftware;
    private javax.swing.JLabel transacaoTxt1;
    private javax.swing.JLabel usuario1Txt;
    private javax.swing.JLabel usuarioFuncionario;
    private javax.swing.JTextField usuarioFuncionarioTxt;
    private javax.swing.JLabel valorPag;
    private javax.swing.JTextField valorPagTxt;
    private javax.swing.JLabel verFuncFuncao;
    private javax.swing.JPanel verFuncFuncaoBtn;
    private javax.swing.JLabel verHospFuncao;
    private javax.swing.JPanel verHospFuncaoBtn;
    private javax.swing.JButton verHospedeBtn;
    private javax.swing.JButton verQuartoBtn;
    // End of variables declaration//GEN-END:variables
}
