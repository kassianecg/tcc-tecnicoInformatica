package hotel;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Funcionario {

    int idFuncionario = 0;
    String nome = "";
    String sexo = "";//enum no mysql, valores possíveis: "F" e "M"
    String nascimento = "";//date mysql FORMATO PADRÃO É: "AAAA-MM-DD"
    String endereco = "";
    String dataContratacao = "";//date mysql FORMATO PADRÃO É: "AAAA-MM-DD"
    String cargo = "";
    String cargaHoraria = "";
    String cpf = "";
    String rg = "";
    String telefone = "";
    String email = "";
    String dataCadastro = "";//datetime no mysql FORMATO PADRÃO É "AAAA-MM-DD HH:MM:SS"
    String usuario = "";
    String senha = "";

    public void gravar() {
        String data = new SimpleDateFormat("yyyy-MM-dd").format(new Date());//pega a data do sistema no formato AAAA-MM-DD
        String hora = new SimpleDateFormat("HH:mm:ss").format(new Date());//pega a hora do sistema no formato HH:MM:SS
        String dataCadFunc = data + " " + hora;//concatena data e hora respectivamente com um espaço entre

        new Conexao().executaComando("INSERT INTO funcionarios (usuario,senha,nome,sexo,nascimento,endereco,dataContratacao,cargo,cargaHoraria,cpf,rg,telefone,email,dataCadastro)"
                + " VALUES ('" + usuario + "','" + senha + "','" + nome + "','" + sexo + "','"
                + nascimento + "','" + endereco + "','"
                + dataContratacao + "','" + cargo + "'," + cargaHoraria + ",'"
                + cpf + "','" + rg + "','" + telefone + "','" + email + "','" + dataCadFunc + "');");

    }

}
