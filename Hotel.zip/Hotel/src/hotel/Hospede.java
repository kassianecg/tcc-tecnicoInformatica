package hotel;

public class Hospede {

    int idHospede = 0;
    String nome = "";
    String sexo = "";// valores possíveis: "F" e "M"
    String nascimento; //date mysql FORMATO PADRÃO É: AAAA-MM-DD
    String cidade = "";
    String cpf = "";
    String rg = "";
    String telefone = "";

    public void gravar() {
        new Conexao().executaComando("INSERT INTO hospedes(nome,sexo,nascimento,cidade,cpf,rg,telefone) VALUES ('"
                + nome + "','" + sexo + "','" + nascimento + "','" + cidade + "','"
                + cpf + "','" + rg + "','" + telefone + "');");
    }

}
