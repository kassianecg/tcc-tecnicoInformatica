package hotel;

public class Reserva {

    int id = 0;
    int idHospede = 0;
    int numQuarto = 0;
    double consumo = 0;
    String dataEntrada = "";//datetime
    String dataSaida = "";//datetime
    String estado = "";//10 caracteres

    public void gravar() {
        new Conexao().executaComando("INSERT INTO reservas(id_hospede ,num_quarto ,dataEntrada ,dataSaida ,estado ,consumo) VALUES ("
                + idHospede + "," + numQuarto + ",'" + dataEntrada + "','" + dataSaida + "','"
                + estado + "'," + consumo + ");");
    }

}
