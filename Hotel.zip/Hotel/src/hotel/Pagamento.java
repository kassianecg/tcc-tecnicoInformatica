package hotel;

public class Pagamento {

    int id = 0;
    int idFluxo = 0;
    double valor = 0;
    String Fpagamento = "";
    String data = "";

    public void gravar() {
        new Conexao().executaComando("INSERT INTO pagamento(id_Fluxo ,valor ,Fpagamento ,data ) VALUES ("
                + idFluxo + "," + valor + ",'" + Fpagamento + "','" + data + "');");
    }

}
