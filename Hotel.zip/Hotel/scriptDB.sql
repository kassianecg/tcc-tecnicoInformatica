drop database hotel;
create database if not exists hotel;

#TABELA FUNCIONARIOS
use hotel;
create table funcionarios (
	idFuncionario double primary key auto_increment,
	nome varchar (100) not null,
	sexo enum ('M', 'F'),
	nascimento date not null,
	endereco varchar (200) not null,
	dataContratacao date not null,
	cargo varchar (50),
	cargaHoraria double,
	cpf varchar (14) unique not null,
	rg varchar (12) unique not null,
	telefone varchar(16),
	email varchar(50),
	dataCadastro datetime not null,
	salario double,
	usuario varchar(100),
	senha varchar(100)
);

#TABELA HOSPEDES
use hotel;
create table hospedes (
	idHospede int primary key auto_increment,
	nome varchar (100),
	sexo enum ('M', 'F'),
	nascimento date not null,
	cidade varchar(50),
	cpf varchar(14) unique not null,
	rg varchar (16) unique not null,
	telefone varchar(16)
);

#TABELA QUARTOS
use hotel;
create table quartos (
	numero int primary key,
	andar int,
	tipo varchar (25),
	descricao varchar (500),
	preco double,
	disponivel enum ('S', 'N')
);

#TABELA DE CONTROLE DE DINHEIRO
/*use hotel;
create table fluxodecaixa (
	idFluxo int primary key auto_increment,
	nome varchar(100),
	valor double,
	data date,
	ESD enum ('Pagar', 'Receber')
);*/

#TABELA DE ESTOQUE
/*use hotel;
create table estoque (
	idEstoque double primary key auto_increment,
	nome varchar(100),
	descricao varchar(200),
	quantidade int,
	valor double,
	validade date
);*/

#TABELA RESERVAS
use hotel;
create table reservas(
	idReserva int primary key auto_increment,
	id_hospede int,
	num_quarto int,
	dataEntrada datetime,
	dataSaida datetime,
	estado varchar(10),
	consumo double,

	foreign key (id_hospede) references hospedes (idHospede),
	foreign key (num_quarto) references quartos (numero)/*,
	foreign key (consumo) references estoque (idEstoque)*/
);

#TABELA PAGAMENTOS - GERAR RELATÓRIO
use hotel;
create table pagamento(
	idPagamento int primary key auto_increment,
	valor double,
	Fpagamento varchar(10),
	data datetime/*,
	id_Fluxo int,
	pFuncionario double,

	foreign key (id_Fluxo) references fluxodecaixa (idFluxo),
	foreign key (pFuncionario) references funcionarios (salario)*/
);

#LEMBRETES
use hotel;
create table lembrete (
	idLembrete int primary key auto_increment,
	nomeUsuario varchar(100),
	assunto varchar(100),
	data datetime,
	descricao varchar(250)
);

#INSERTS
use hotel;
insert into funcionarios(usuario,senha,nome,sexo,nascimento,endereco,dataContratacao,cargo,cargaHoraria,cpf,rg,telefone,email,dataCadastro,salario) 
values("admin","admin",'Luis Gustavo de Freitas','M','2002-04-09','R. do Luis','2019-08-08','Gerente de TI','8','111.111.111-1','11.111.111-1','199123-4567','luisgufreitas1989@gmail.com','2019-08-27 15:27:12','2100.00'),
("pedro","0511",'Pedro da Silva','M','1999-05-19','R. do Pedro','2017-05-11','Recepcionista','8','222.222.222-2','22.222.222-2','199891-0111','silvapedro0519@gmail.com','2019-08-27 15:29:12','1700.00');

use hotel;
insert into hospedes(nome,sexo,nascimento,cidade,cpf,rg,telefone)
values('Kássio','M','2002-08-01','São João da Boa Vista','111.111.111-1','11.111.111-1','199123-4567'),
('Mariana','F','1998-05-17','São Paulo','222.222.222-2','22.222.222-2','199891-0111');

use hotel;
insert into quartos(numero,andar,tipo,descricao,preco,disponivel)
values(1,0,'Médio','Quarto simples para duas pessoas com custo benefício bom',900.00,'N'),
(88,8,'Suíte de Luxo','Suíte de luxo com as melhores regalias para o melhor conforto disponível',5000.00,'S');

use hotel;
insert into reservas(id_hospede,num_quarto,dataEntrada,dataSaida,estado,consumo)
values(1,88,'2019-08-29 13:06:22','2019-09-14 16:58:31','Concluído',749.83),
(2,1,'2019-08-27 15:44:59','2019-09-10 12:04:33','Em estadia',395.79);

use hotel;
insert into pagamento(valor,Fpagamento,data)
values(534.31,'Crédito','2019-08-27 17:32:14'),
(349.55,'Boleto','2019-08-27 17:44:23');

insert into lembrete(nomeUsuario,assunto,data,descricao)
values('Pedro','Pagar conta de eletricidade 2ªfeira','2019-08-27 14:00:00','Conta de eletricidade boleto R$600.00 na lotérica na avenida principal'),
('Luis','Pagar encanador','2019-08-27 16:27:15','Encanador consertou vazamento no quarto 1 térreo essa semana R$250.00');

#SELECTS
use hotel;
#seleciona os quarto disponivel com preço igual ou menor que 5000
select * from quartos where preco <=5000 and disponivel = 'S';

use hotel;
#retorna nome do usuario, o numero do quarto que ele ficou, data de entrada e data de saída da reserva, o estado do quarto e o estado da reserva listando os nomes em ordem crescente(alfabética)
select hospedes.nome,numero,andar,disponivel,consumo,dataEntrada,dataSaida,estado from reservas,hospedes,quartos where idHospede = id_hospede and numero = num_quarto order by nome asc;

use hotel;
#verifica se o usuário é igual 'admin' e senha igual a 'admin'
select usuario,senha from funcionarios where usuario='admin' and senha='admin';

use hotel;
#seleciona todos os campos da tabela de lembretes que tem a data depois de 2019-08-27 e da hora 15:00:00
select * from lembrete where data >= '2019-08-27 15:00:00';

select ('Script do Banco Pronto');